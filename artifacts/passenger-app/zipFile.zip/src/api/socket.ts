import { io, Socket } from 'socket.io-client';
import { Platform } from 'react-native';
import { tokenStore } from './client';

const SOCKET_URL = (process.env.EXPO_PUBLIC_API_URL ?? 'http://localhost:3000/api')
  .replace(/\/api\/?$/, '');

let socket: Socket | null = null;

export async function getSocket(): Promise<Socket> {
  if (socket && socket.connected) return socket;

  const token = await tokenStore.getToken(tokenStore.TOKEN_KEY);

  if (socket) {
    socket.disconnect();
    socket = null;
  }

  socket = io(SOCKET_URL, {
    transports: Platform.OS === 'web' ? ['websocket', 'polling'] : ['websocket'],
    auth: token ? { token } : {},
    reconnection: true,
    reconnectionAttempts: 10,
    reconnectionDelay: 1500,
    timeout: 10000,
  });

  socket.on('connect', () => {
    console.log('[Socket] connected:', socket?.id);
  });

  socket.on('connect_error', (err) => {
    console.warn('[Socket] connection error:', err.message);
  });

  socket.on('disconnect', (reason) => {
    console.log('[Socket] disconnected:', reason);
  });

  return socket;
}

export function disconnectSocket() {
  if (socket) {
    socket.disconnect();
    socket = null;
  }
}

export type RideStatus =
  | 'searching'
  | 'driver_assigned'
  | 'driver_en_route'
  | 'started'
  | 'completed'
  | 'cancelled'
  | 'timeout';

export interface DriverLocation {
  latitude: number;
  longitude: number;
  heading?: number;
}

export interface RideSocketEvents {
  'ride:driver_assigned': (data: { rideId: string; driver: { name: string; phone: string; vehicle: string; rating: number }; eta: number }) => void;
  'ride:driver_location': (data: { rideId: string; location: DriverLocation }) => void;
  'ride:started': (data: { rideId: string }) => void;
  'ride:completed': (data: { rideId: string; fare: number }) => void;
  'ride:cancelled': (data: { rideId: string; reason: string }) => void;
  'ride:timeout': (data: { rideId: string }) => void;
  'notification:new': (data: { id: string; category: string; title: string; body: string; time: string }) => void;
}
