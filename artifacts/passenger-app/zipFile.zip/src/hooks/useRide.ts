import { useState, useCallback, useRef } from 'react';
import api from '../api/client';
import { getSocket, type RideStatus, type DriverLocation } from '../api/socket';

export interface DriverInfo {
  name: string;
  phone: string;
  vehicle: string;
  rating: number;
  eta: number;
}

export interface RideState {
  rideId: string | null;
  status: RideStatus;
  driver: DriverInfo | null;
  driverLocation: DriverLocation | null;
  fare: number | null;
  cancelReason: string | null;
}

interface UseRideResult {
  rideState: RideState;
  requesting: boolean;
  requestRide: (payload: {
    type: 'car' | 'bike';
    pickup: { latitude: number; longitude: number; address?: string };
    dropoff: { latitude: number; longitude: number; address?: string };
    notes?: string;
  }) => Promise<{ success: boolean; rideId?: string; error?: string }>;
  cancelRide: () => Promise<void>;
  resetRide: () => void;
}

const DEFAULT_STATE: RideState = {
  rideId: null,
  status: 'searching',
  driver: null,
  driverLocation: null,
  fare: null,
  cancelReason: null,
};

export function useRide(): UseRideResult {
  const [rideState, setRideState] = useState<RideState>(DEFAULT_STATE);
  const [requesting, setRequesting] = useState(false);
  const socketListening = useRef(false);

  const setupSocketListeners = useCallback(async (rideId: string) => {
    if (socketListening.current) return;
    socketListening.current = true;
    try {
      const socket = await getSocket();

      socket.on('ride:driver_assigned', (data: any) => {
        if (data.rideId !== rideId) return;
        setRideState((prev) => ({
          ...prev,
          status: 'driver_assigned',
          driver: {
            name: data.driver?.name ?? 'Driver',
            phone: data.driver?.phone ?? '',
            vehicle: data.driver?.vehicle ?? '',
            rating: data.driver?.rating ?? 4.8,
            eta: data.eta ?? 5,
          },
        }));
      });

      socket.on('ride:driver_location', (data: any) => {
        if (data.rideId !== rideId) return;
        setRideState((prev) => ({ ...prev, driverLocation: data.location }));
      });

      socket.on('ride:started', (data: any) => {
        if (data.rideId !== rideId) return;
        setRideState((prev) => ({ ...prev, status: 'started' }));
      });

      socket.on('ride:completed', (data: any) => {
        if (data.rideId !== rideId) return;
        setRideState((prev) => ({ ...prev, status: 'completed', fare: data.fare ?? null }));
        socketListening.current = false;
        socket.off('ride:driver_assigned');
        socket.off('ride:driver_location');
        socket.off('ride:started');
        socket.off('ride:completed');
        socket.off('ride:cancelled');
        socket.off('ride:timeout');
      });

      socket.on('ride:cancelled', (data: any) => {
        if (data.rideId !== rideId) return;
        setRideState((prev) => ({ ...prev, status: 'cancelled', cancelReason: data.reason ?? null }));
        socketListening.current = false;
      });

      socket.on('ride:timeout', (data: any) => {
        if (data.rideId !== rideId) return;
        setRideState((prev) => ({ ...prev, status: 'timeout' }));
        socketListening.current = false;
      });
    } catch (err) {
      console.warn('[useRide] Socket setup failed:', err);
    }
  }, []);

  const requestRide = useCallback(async (payload: {
    type: 'car' | 'bike';
    pickup: { latitude: number; longitude: number; address?: string };
    dropoff: { latitude: number; longitude: number; address?: string };
    notes?: string;
  }) => {
    setRequesting(true);
    setRideState(DEFAULT_STATE);
    try {
      const { data } = await api.post('/rides/request', payload);
      const rideId = data.rideId ?? data.id ?? data._id ?? String(Date.now());
      setRideState((prev) => ({ ...prev, rideId, status: 'searching' }));
      await setupSocketListeners(rideId);
      return { success: true, rideId };
    } catch (e: any) {
      const error = e?.response?.data?.message ?? e?.message ?? 'Failed to request ride';
      setRideState((prev) => ({ ...prev, status: 'cancelled', cancelReason: error }));
      return { success: false, error };
    } finally {
      setRequesting(false);
    }
  }, [setupSocketListeners]);

  const cancelRide = useCallback(async () => {
    const { rideId } = rideState;
    if (rideId) {
      try {
        await api.post(`/rides/${rideId}/cancel`);
      } catch {}
    }
    setRideState((prev) => ({ ...prev, status: 'cancelled', cancelReason: 'Cancelled by user' }));
    socketListening.current = false;
  }, [rideState]);

  const resetRide = useCallback(() => {
    setRideState(DEFAULT_STATE);
    socketListening.current = false;
  }, []);

  return { rideState, requesting, requestRide, cancelRide, resetRide };
}
