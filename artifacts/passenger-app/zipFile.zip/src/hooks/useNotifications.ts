import { useState, useEffect, useCallback, useRef } from 'react';
import api from '../api/client';
import { getSocket } from '../api/socket';
import { notifications as MOCK_NOTIFICATIONS, type Notification } from '@/constants/data';

interface UseNotificationsResult {
  notifications: Notification[];
  unreadCount: number;
  loading: boolean;
  error: string | null;
  markAllRead: () => void;
  refresh: () => void;
}

function mapApiNotif(n: any): Notification {
  const cat = (n.category ?? n.type ?? 'system').toLowerCase();
  return {
    id: n.id ?? n._id ?? String(Math.random()),
    category: (cat === 'trip' || cat === 'promo' || cat === 'system') ? cat as any : 'system',
    title: n.title ?? n.subject ?? '',
    body: n.body ?? n.message ?? n.content ?? '',
    time: n.time ?? n.createdAt ?? n.timestamp ?? '',
    unread: n.unread ?? n.isRead === false ?? false,
  };
}

export function useNotifications(): UseNotificationsResult {
  const [notifications, setNotifications] = useState<Notification[]>(MOCK_NOTIFICATIONS);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const socketSetup = useRef(false);

  const fetchNotifications = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const { data } = await api.get('/notifications');
      const list = Array.isArray(data) ? data : data.notifications ?? data.data ?? [];
      if (list.length > 0) setNotifications(list.map(mapApiNotif));
    } catch (e: any) {
      setError(e?.response?.data?.message ?? e?.message ?? 'Failed to load notifications');
      setNotifications(MOCK_NOTIFICATIONS);
    } finally {
      setLoading(false);
    }
  }, []);

  const markAllRead = useCallback(() => {
    setNotifications((prev) => prev.map((n) => ({ ...n, unread: false })));
    api.patch('/notifications/read-all').catch(() => {});
  }, []);

  useEffect(() => {
    fetchNotifications();

    if (socketSetup.current) return;
    socketSetup.current = true;

    getSocket().then((socket) => {
      socket.on('notification:new', (data: any) => {
        setNotifications((prev) => [mapApiNotif({ ...data, unread: true }), ...prev]);
      });
    }).catch(() => {});

    return () => {
      getSocket().then((socket) => {
        socket.off('notification:new');
      }).catch(() => {});
    };
  }, []);

  const unreadCount = notifications.filter((n) => n.unread).length;

  return { notifications, unreadCount, loading, error, markAllRead, refresh: fetchNotifications };
}
