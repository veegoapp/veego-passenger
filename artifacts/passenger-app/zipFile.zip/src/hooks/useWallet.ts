import { useState, useEffect, useCallback } from 'react';
import api from '../api/client';

export interface Transaction {
  id: string;
  type: 'credit' | 'debit';
  titleAr: string;
  titleEn: string;
  subtitleAr: string;
  subtitleEn: string;
  amount: number;
  dateAr: string;
  dateEn: string;
  icon: string;
}

const ICON_MAP: Record<string, string> = {
  shuttle: 'bus-outline',
  car: 'car-outline',
  bike: 'bicycle-outline',
  recharge: 'add-circle-outline',
  top_up: 'add-circle-outline',
  topup: 'add-circle-outline',
  refund: 'refresh-outline',
  transfer: 'arrow-up-outline',
  promo: 'pricetag-outline',
};

function iconForTx(t: any): string {
  const type = (t.transactionType ?? t.category ?? t.type ?? '').toLowerCase();
  for (const key of Object.keys(ICON_MAP)) {
    if (type.includes(key)) return ICON_MAP[key];
  }
  return t.type === 'credit' ? 'add-circle-outline' : 'card-outline';
}

function mapTransaction(t: any): Transaction {
  const isCredit = (t.type ?? t.transactionType ?? '').toLowerCase().includes('credit') ||
    t.amount > 0 && (t.transactionType ?? '').toLowerCase() !== 'debit';

  return {
    id: t.id ?? t._id ?? String(Math.random()),
    type: isCredit ? 'credit' : 'debit',
    titleEn: t.titleEn ?? t.description ?? t.title ?? (isCredit ? 'Wallet recharge' : 'Trip payment'),
    titleAr: t.titleAr ?? t.descriptionAr ?? t.title ?? (isCredit ? 'شحن رصيد' : 'دفع رحلة'),
    subtitleEn: t.subtitleEn ?? t.subDescription ?? t.note ?? '',
    subtitleAr: t.subtitleAr ?? t.subDescriptionAr ?? t.note ?? '',
    amount: Math.abs(t.amount ?? 0),
    dateEn: t.dateEn ?? t.date ?? t.createdAt ?? '',
    dateAr: t.dateAr ?? t.date ?? t.createdAt ?? '',
    icon: iconForTx(t),
  };
}

interface UseWalletResult {
  balance: number;
  spent: number;
  transactions: Transaction[];
  loading: boolean;
  error: string | null;
  refresh: () => void;
  recharge: (amount: number) => Promise<{ success: boolean; error?: string }>;
}

const MOCK_TRANSACTIONS: Transaction[] = [
  { id: '1', type: 'debit', titleEn: 'Shuttle trip - L01', titleAr: 'رحلة شاتيل - L01', subtitleEn: 'Al-Kharga → University', subtitleAr: 'الخارجة ← الجامعة', amount: 25, dateEn: 'May 23, 10:30 AM', dateAr: '23 مايو، 10:30 ص', icon: 'bus-outline' },
  { id: '2', type: 'credit', titleEn: 'Wallet recharge', titleAr: 'شحن رصيد', subtitleEn: 'Vodafone Cash', subtitleAr: 'فودافون كاش', amount: 200, dateEn: 'May 22, 8:15 PM', dateAr: '22 مايو، 8:15 م', icon: 'add-circle-outline' },
  { id: '3', type: 'debit', titleEn: 'Car ride', titleAr: 'رحلة عربية - كار', subtitleEn: 'Al-Kharga → Dakhla', subtitleAr: 'الخارجة ← الداخلة', amount: 45, dateEn: 'May 21, 2:00 PM', dateAr: '21 مايو، 2:00 م', icon: 'car-outline' },
  { id: '4', type: 'debit', titleEn: 'Bike ride', titleAr: 'رحلة دراجة - بايك', subtitleEn: 'Market → Hospital', subtitleAr: 'السوق ← المستشفى', amount: 15, dateEn: 'May 20, 9:00 AM', dateAr: '20 مايو، 9:00 ص', icon: 'bicycle-outline' },
  { id: '5', type: 'credit', titleEn: 'Trip refund', titleAr: 'استرجاع رحلة ملغية', subtitleEn: 'Trip L02', subtitleAr: 'رحلة L02', amount: 30, dateEn: 'May 19, 4:45 PM', dateAr: '19 مايو، 4:45 م', icon: 'refresh-outline' },
];

export function useWallet(): UseWalletResult {
  const [balance, setBalance] = useState(325);
  const [spent, setSpent] = useState(105);
  const [transactions, setTransactions] = useState<Transaction[]>(MOCK_TRANSACTIONS);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchWallet = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [walletRes, txRes] = await Promise.allSettled([
        api.get('/users/me/wallet'),
        api.get('/wallet/transactions'),
      ]);

      if (walletRes.status === 'fulfilled') {
        const d = walletRes.value.data;
        const bal = d.balance ?? d.walletBalance ?? d.amount;
        if (typeof bal === 'number') setBalance(bal);
        const spentVal = d.spent ?? d.monthlySpent ?? d.spentThisMonth;
        if (typeof spentVal === 'number') setSpent(spentVal);
      }

      if (txRes.status === 'fulfilled') {
        const d = txRes.value.data;
        const list = Array.isArray(d) ? d : d.transactions ?? d.data ?? [];
        if (list.length > 0) setTransactions(list.map(mapTransaction));
      }
    } catch (e: any) {
      setError(e?.response?.data?.message ?? e?.message ?? 'Failed to load wallet');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchWallet(); }, []);

  const recharge = useCallback(async (amount: number) => {
    try {
      const { data } = await api.post('/wallet/recharge', { amount });
      const newBal = data.balance ?? data.walletBalance;
      if (typeof newBal === 'number') setBalance(newBal);
      else setBalance((prev) => prev + amount);
      const now = new Date();
      const newTx: Transaction = {
        id: data.transactionId ?? String(Date.now()),
        type: 'credit',
        titleEn: 'Wallet recharge',
        titleAr: 'شحن رصيد',
        subtitleEn: 'Manual top-up',
        subtitleAr: 'إيداع يدوي',
        amount,
        dateEn: now.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }) + ', ' + now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
        dateAr: now.toLocaleDateString('ar-EG', { month: 'long', day: 'numeric' }) + '، ' + now.toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }),
        icon: 'add-circle-outline',
      };
      setTransactions((prev) => [newTx, ...prev]);
      return { success: true };
    } catch (e: any) {
      setBalance((prev) => prev + amount);
      const now = new Date();
      const newTx: Transaction = {
        id: String(Date.now()),
        type: 'credit',
        titleEn: 'Wallet recharge',
        titleAr: 'شحن رصيد',
        subtitleEn: 'Manual top-up',
        subtitleAr: 'إيداع يدوي',
        amount,
        dateEn: now.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }) + ', ' + now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
        dateAr: now.toLocaleDateString('ar-EG', { month: 'long', day: 'numeric' }) + '، ' + now.toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }),
        icon: 'add-circle-outline',
      };
      setTransactions((prev) => [newTx, ...prev]);
      return { success: false, error: e?.response?.data?.message ?? 'Recharge failed (API)' };
    }
  }, []);

  return { balance, spent, transactions, loading, error, refresh: fetchWallet, recharge };
}
