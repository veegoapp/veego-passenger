import { useState, useEffect, useCallback } from 'react';
import api from '../api/client';

export interface UserProfile {
  name: string;
  email: string;
  dob: string;
  phone: string;
}

const DEFAULT_PROFILE: UserProfile = {
  name: 'يوسف عادل',
  email: 'youssef@example.com',
  dob: '01/01/1995',
  phone: '+20 100 000 0000',
};

interface UseProfileResult {
  profile: UserProfile;
  loading: boolean;
  error: string | null;
  saveProfile: (updates: Partial<UserProfile>) => Promise<{ success: boolean; error?: string }>;
  refresh: () => void;
}

function mapApiProfile(d: any): UserProfile {
  return {
    name: d.name ?? d.fullName ?? d.displayName ?? DEFAULT_PROFILE.name,
    email: d.email ?? d.emailAddress ?? DEFAULT_PROFILE.email,
    dob: d.dob ?? d.dateOfBirth ?? d.birthdate ?? DEFAULT_PROFILE.dob,
    phone: d.phone ?? d.phoneNumber ?? d.mobile ?? DEFAULT_PROFILE.phone,
  };
}

export function useProfile(): UseProfileResult {
  const [profile, setProfile] = useState<UserProfile>(DEFAULT_PROFILE);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchProfile = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const { data } = await api.get('/auth/me');
      const d = data.user ?? data.profile ?? data;
      setProfile(mapApiProfile(d));
    } catch (e: any) {
      setError(e?.response?.data?.message ?? e?.message ?? 'Failed to load profile');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchProfile(); }, []);

  const saveProfile = useCallback(async (updates: Partial<UserProfile>) => {
    try {
      const { data } = await api.patch('/users/me', updates);
      const d = data.user ?? data.profile ?? data;
      setProfile((prev) => ({ ...prev, ...mapApiProfile(d) }));
      return { success: true };
    } catch (e: any) {
      setProfile((prev) => ({ ...prev, ...updates }));
      return { success: false, error: e?.response?.data?.message ?? 'Save failed (API)' };
    }
  }, []);

  return { profile, loading, error, saveProfile, refresh: fetchProfile };
}
