import { useState, useEffect, useCallback } from 'react';
import api from '../api/client';
import { upcomingTrips as MOCK_UPCOMING, pastTrips as MOCK_PAST, type Trip, type TripType } from '@/constants/data';

interface UseTripsResult {
  upcomingTrips: Trip[];
  pastTrips: Trip[];
  loading: boolean;
  error: string | null;
  refresh: () => void;
}

function mapApiTrip(t: any): Trip {
  const status: Trip['status'] =
    t.status === 'cancelled' ? 'cancelled' :
    t.status === 'completed' || t.status === 'past' ? 'completed' : 'upcoming';

  const typeRaw = (t.type ?? t.tripType ?? 'shuttle').toLowerCase();
  const type: TripType =
    typeRaw === 'car' ? 'car' : typeRaw === 'bike' ? 'bike' : 'shuttle';

  return {
    id: t.id ?? t._id ?? String(Math.random()),
    type,
    routeCode: t.routeCode ?? t.lineCode ?? (type === 'car' ? 'CAR' : type === 'bike' ? 'BIKE' : 'L00'),
    routeName: t.routeName ?? t.name ?? t.lineName ?? '—',
    from: t.from ?? t.origin ?? t.pickup ?? '—',
    to: t.to ?? t.destination ?? t.dropoff ?? '—',
    date: t.date ?? t.travelDate ?? '—',
    time: t.time ?? t.departureTime ?? t.scheduledTime ?? '—',
    seat: t.seat ?? t.seatNumber ?? '—',
    status,
    price: t.price ?? t.fare ?? t.amount ?? 0,
  };
}

export function useTrips(): UseTripsResult {
  const [upcomingTrips, setUpcomingTrips] = useState<Trip[]>(MOCK_UPCOMING);
  const [pastTrips, setPastTrips] = useState<Trip[]>(MOCK_PAST);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchTrips = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const { data } = await api.get('/users/me/bookings');
      const allTrips: any[] = Array.isArray(data) ? data : data.bookings ?? data.trips ?? data.data ?? [];
      const mapped = allTrips.map(mapApiTrip);
      const upcoming = mapped.filter((t) => t.status === 'upcoming');
      const past = mapped.filter((t) => t.status !== 'upcoming');
      setUpcomingTrips(upcoming.length > 0 ? upcoming : MOCK_UPCOMING);
      setPastTrips(past.length > 0 ? past : MOCK_PAST);
    } catch (e: any) {
      const msg = e?.response?.data?.message ?? e?.message ?? 'Failed to load trips';
      setError(msg);
      setUpcomingTrips(MOCK_UPCOMING);
      setPastTrips(MOCK_PAST);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchTrips(); }, []);

  return { upcomingTrips, pastTrips, loading, error, refresh: fetchTrips };
}
