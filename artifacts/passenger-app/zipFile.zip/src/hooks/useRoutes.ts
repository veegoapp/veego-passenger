import { useState, useEffect, useCallback } from 'react';
import api from '../api/client';
import { routes as MOCK_ROUTES, type Route } from '@/constants/data';

interface UseRoutesResult {
  routes: Route[];
  loading: boolean;
  error: string | null;
  refresh: () => void;
}

function mapApiRoute(r: any): Route {
  return {
    id: r.id ?? r._id ?? String(Math.random()),
    code: r.code ?? r.routeCode ?? 'L00',
    name: r.name ?? r.routeName ?? '',
    from: r.from ?? r.origin ?? '',
    to: r.to ?? r.destination ?? '',
    stations: r.stations ?? r.stationCount ?? 0,
    duration: r.duration ?? r.estimatedDuration ?? '—',
    seatsLeft: r.seatsLeft ?? r.availableSeats ?? 0,
    totalSeats: r.totalSeats ?? r.capacity ?? 18,
    price: r.price ?? r.fare ?? 0,
    nextDeparture: r.nextDeparture ?? r.nextDepartureTime ?? '—',
    color: r.color ?? '#d8ecf7',
    path: Array.isArray(r.path) ? r.path.map((s: any) => ({
      id: s.id ?? s._id ?? String(Math.random()),
      name: s.name ?? '',
      area: s.area ?? '',
      distance: s.distance ?? '—',
      eta: s.eta ?? '—',
    })) : [],
  };
}

export function useRoutes(): UseRoutesResult {
  const [routes, setRoutes] = useState<Route[]>(MOCK_ROUTES);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchRoutes = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const { data } = await api.get('/routes');
      const list = Array.isArray(data) ? data : data.routes ?? data.data ?? [];
      if (list.length > 0) {
        setRoutes(list.map(mapApiRoute));
      }
    } catch (e: any) {
      const msg = e?.response?.data?.message ?? e?.message ?? 'Failed to load routes';
      setError(msg);
      setRoutes(MOCK_ROUTES);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchRoutes(); }, []);

  return { routes, loading, error, refresh: fetchRoutes };
}
