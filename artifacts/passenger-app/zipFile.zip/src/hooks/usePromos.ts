import { useState, useEffect, useCallback } from 'react';
import api from '../api/client';

export interface PromoCard {
  code: string;
  titleEn: string;
  titleAr: string;
  subtitleEn: string;
  subtitleAr: string;
  discount: string;
  expiresEn: string;
  expiresAr: string;
  color: string;
  icon: string;
}

const FALLBACK_PROMOS: PromoCard[] = [
  { code: 'VEEGO10', titleEn: '10% off your next ride', titleAr: '١٠٪ خصم على رحلتك القادمة', subtitleEn: 'Valid on car & bike rides', subtitleAr: 'صالح لرحلات السيارة والدراجة', discount: '10%', expiresEn: 'Jun 30, 2026', expiresAr: '٣٠ يونيو ٢٠٢٦', color: '#55c49a', icon: 'sparkles-outline' },
  { code: 'WADI25', titleEn: '25 EGP wallet credit', titleAr: 'رصيد محفظة ٢٥ ج.م', subtitleEn: 'Recharge bonus for all users', subtitleAr: 'مكافأة شحن لجميع المستخدمين', discount: '25 EGP', expiresEn: 'Jul 15, 2026', expiresAr: '١٥ يوليو ٢٠٢٦', color: '#4d9ef6', icon: 'wallet-outline' },
  { code: 'NEWUSER', titleEn: '15% off — New user deal', titleAr: '١٥٪ خصم لأول رحلة', subtitleEn: 'First ride only', subtitleAr: 'للرحلة الأولى فقط', discount: '15%', expiresEn: 'Dec 31, 2026', expiresAr: '٣١ ديسمبر ٢٠٢٦', color: '#d95c35', icon: 'gift-outline' },
];

const COLORS = ['#55c49a', '#4d9ef6', '#d95c35', '#a855f7', '#f59e0b'];
const ICONS = ['sparkles-outline', 'wallet-outline', 'gift-outline', 'star-outline', 'pricetag-outline'];

function mapApiPromo(p: any, idx: number): PromoCard {
  const discount = p.discount ?? p.discountValue ?? p.value ?? '';
  const discountStr = typeof discount === 'number'
    ? (p.discountType === 'percent' || p.type === 'percent' ? `${discount}%` : `${discount} EGP`)
    : String(discount);

  return {
    code: p.code ?? p.promoCode ?? '',
    titleEn: p.titleEn ?? p.title ?? p.name ?? p.description ?? '',
    titleAr: p.titleAr ?? p.title ?? p.name ?? p.description ?? '',
    subtitleEn: p.subtitleEn ?? p.subtitle ?? p.shortDescription ?? '',
    subtitleAr: p.subtitleAr ?? p.subtitle ?? p.shortDescription ?? '',
    discount: discountStr,
    expiresEn: p.expiresEn ?? p.expiresAt ?? p.validUntil ?? p.expiry ?? '',
    expiresAr: p.expiresAr ?? p.expiresAt ?? p.validUntil ?? p.expiry ?? '',
    color: p.color ?? COLORS[idx % COLORS.length],
    icon: p.icon ?? ICONS[idx % ICONS.length],
  };
}

interface UsePromosResult {
  promos: PromoCard[];
  loading: boolean;
  validateCode: (code: string) => Promise<{ valid: boolean; discount?: string; message?: string }>;
}

export function usePromos(): UsePromosResult {
  const [promos, setPromos] = useState<PromoCard[]>(FALLBACK_PROMOS);
  const [loading, setLoading] = useState(false);

  const fetchPromos = useCallback(async () => {
    setLoading(true);
    try {
      const { data } = await api.get('/promo/available');
      const list = Array.isArray(data) ? data : data.promos ?? data.data ?? [];
      if (list.length > 0) setPromos(list.map(mapApiPromo));
    } catch {
      setPromos(FALLBACK_PROMOS);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchPromos(); }, []);

  const validateCode = useCallback(async (code: string) => {
    try {
      const { data } = await api.post('/promo/validate', { code });
      const valid = data.valid ?? data.isValid ?? data.success ?? true;
      const discount = data.discount ?? data.discountValue ?? data.value ?? '';
      const discountStr = typeof discount === 'number'
        ? (data.type === 'percent' ? `${discount}%` : `${discount} EGP`)
        : String(discount);
      return { valid: Boolean(valid), discount: discountStr, message: data.message };
    } catch (e: any) {
      const status = (e as any)?.response?.status;
      if (status === 404 || status === 400 || status === 422) {
        return { valid: false, message: e?.response?.data?.message ?? 'Invalid promo code' };
      }
      const FALLBACK: Record<string, string> = { VEEGO10: '10%', WADI25: '25 EGP', NEWUSER: '15%', RIDE50: '50 EGP' };
      if (FALLBACK[code.toUpperCase()]) {
        return { valid: true, discount: FALLBACK[code.toUpperCase()] };
      }
      return { valid: false, message: 'Could not validate code' };
    }
  }, []);

  return { promos, loading, validateCode };
}
