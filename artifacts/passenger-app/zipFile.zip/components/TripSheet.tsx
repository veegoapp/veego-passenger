import React, { useEffect, useRef, useState, useMemo } from 'react';
import { View, Text, TouchableOpacity, ScrollView, StyleSheet, Modal, Animated, Platform } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { useTheme } from '@/context/ThemeContext';
import { ThemeColors, S } from '@/constants/colors';
import { useBooking } from '@/context/BookingContext';
import { DATES, TIMES, calcSegmentPrice } from '@/constants/data';
import { SectionLabel } from '@/components/Shared';

function makeStyles(c: ThemeColors, gs: object) {
  return StyleSheet.create({
    root: { flex: 1 },
    overlay: { ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(0,0,0,0.4)' },
    sheet: { position: 'absolute', bottom: 0, left: 0, right: 0, height: '88%', backgroundColor: c.white, borderTopLeftRadius: 32, borderTopRightRadius: 32, ...S.float },
    handle: { width: 48, height: 6, borderRadius: 3, backgroundColor: c.isDark ? 'rgba(120,120,160,0.4)' : 'rgba(195,195,204,0.7)', alignSelf: 'center', marginTop: 12 },
    scroll: { flex: 1 },
    scrollContent: { padding: 24, paddingBottom: 8, gap: 0 },
    routeHeader: { flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 4 },
    routeCodeBox: { width: 48, height: 48, borderRadius: 16, backgroundColor: c.ink, alignItems: 'center', justifyContent: 'center' },
    routeCodeText: { color: c.isDark ? c.background : c.white, fontSize: 12, fontWeight: '600' },
    routeNameText: { fontSize: 18, fontWeight: '600', color: c.ink, letterSpacing: -0.3 },
    routePathText: { fontSize: 12, color: c.inkSoft, marginTop: 1 },
    heartBtn: { width: 40, height: 40, borderRadius: 20, backgroundColor: c.mist, alignItems: 'center', justifyContent: 'center' },
    section: { marginTop: 20, gap: 8 },
    hScroll: { marginTop: 8 },
    dateBtn: { minWidth: 64, paddingVertical: 10, borderRadius: 16, borderWidth: 1, alignItems: 'center' },
    dateBtnActive: { backgroundColor: c.ink, borderColor: c.ink },
    dateBtnInactive: { backgroundColor: c.white, borderColor: c.border },
    dateDayLabel: { fontSize: 10, textTransform: 'uppercase', letterSpacing: 0.8 },
    dateDay: { fontSize: 18, fontWeight: '600', lineHeight: 24 },
    timeBtn: { height: 44, paddingHorizontal: 16, borderRadius: 16, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
    timeBtnActive: { backgroundColor: c.ink, borderColor: c.ink },
    timeBtnInactive: { backgroundColor: c.white, borderColor: c.border },
    timeText: { fontSize: 13, fontWeight: '500' },
    pickTabWrap: { flexDirection: 'row', padding: 4, borderRadius: 16, marginTop: 8, gap: 2 },
    pickTab: { flex: 1, height: 44, borderRadius: 12, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 8 },
    pickTabActive: { backgroundColor: c.ink },
    pickTabText: { fontSize: 12.5, fontWeight: '500' },
    timeline: { marginTop: 12, backgroundColor: c.mist, borderRadius: 24, padding: 16, gap: 0 },
    timelineRow: { flexDirection: 'row', gap: 12, paddingBottom: 12 },
    timelineLeft: { alignItems: 'center', width: 16 },
    tlDot: { width: 16, height: 16, borderRadius: 8, borderWidth: 2 },
    tlDotActive: { borderColor: c.ink, backgroundColor: c.ink },
    tlDotSeg: { borderColor: c.ink, backgroundColor: c.white },
    tlDotInactive: { borderColor: c.silver, backgroundColor: c.white },
    tlLine: { width: 2, flex: 1, marginTop: 2, minHeight: 16 },
    tlLineActive: { backgroundColor: c.ink },
    tlLineInactive: { backgroundColor: 'rgba(195,195,204,0.5)' },
    timelineRight: { flex: 1, paddingBottom: 4 },
    timelineTextRow: { flexDirection: 'row', alignItems: 'baseline', justifyContent: 'space-between' },
    tlName: { fontSize: 13.5, fontWeight: '500' },
    tlBadge: { backgroundColor: c.ink, borderRadius: 99, paddingHorizontal: 8, paddingVertical: 2 },
    tlBadgeText: { fontSize: 10, fontWeight: '600', color: c.isDark ? c.background : c.white, textTransform: 'uppercase', letterSpacing: 0.8 },
    tlArea: { fontSize: 11, color: c.inkSoft, marginTop: 2 },
    paxRow: { flexDirection: 'row', alignItems: 'center', borderRadius: 20, padding: 16, marginTop: 8 },
    paxCount: { fontSize: 13.5, fontWeight: '600', color: c.ink },
    paxLimit: { fontSize: 11, color: c.inkSoft, marginTop: 2 },
    paxControls: { flexDirection: 'row', alignItems: 'center', gap: 8 },
    paxBtn: { width: 36, height: 36, borderRadius: 18, alignItems: 'center', justifyContent: 'center' },
    paxBtnOutline: { backgroundColor: c.white, borderWidth: 1, borderColor: c.border },
    paxBtnFilled: { backgroundColor: c.ink },
    paxNum: { width: 24, textAlign: 'center', fontSize: 15, fontWeight: '600', color: c.ink },
    priceSummary: { flexDirection: 'row', alignItems: 'center', borderRadius: 24, padding: 16, marginTop: 20, gap: 16 },
    priceIcon: { width: 48, height: 48, borderRadius: 16, backgroundColor: c.ink, alignItems: 'center', justifyContent: 'center' },
    priceSegLabel: { fontSize: 12, color: c.inkSoft },
    priceTotal: { fontSize: 20, fontWeight: '600', color: c.ink, letterSpacing: -0.5 },
    ratingBox: { flexDirection: 'row', alignItems: 'center', gap: 4 },
    ratingText: { fontSize: 11, color: c.inkSoft },
    cta: { padding: 24, paddingTop: 12, borderTopWidth: 1, borderTopColor: c.border, backgroundColor: c.white },
    ctaBtn: { height: 56, borderRadius: 20, backgroundColor: c.ink, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, ...S.float },
    ctaBtnText: { color: c.isDark ? c.background : c.white, fontSize: 15, fontWeight: '600' },
  });
}

export function TripSheet() {
  const { tripSheetOpen, closeTripSheet, selectedRoute, handleBook } = useBooking();
  const { colors: c, glassStyle: gs, t } = useTheme();
  const styles = useMemo(() => makeStyles(c, gs), [c]);
  const slideAnim = useRef(new Animated.Value(0)).current;
  const overlayAnim = useRef(new Animated.Value(0)).current;
  const [visible, setVisible] = useState(false);
  const [fromIdx, setFromIdx] = useState(0);
  const [toIdx, setToIdx] = useState(1);
  const [pax, setPax] = useState(1);
  const [dateIdx, setDateIdx] = useState(0);
  const [timeIdx, setTimeIdx] = useState(0);
  const [pick, setPick] = useState<'from' | 'to'>('from');

  useEffect(() => {
    if (selectedRoute) {
      setFromIdx(0); setToIdx(selectedRoute.path.length - 1);
      setPax(1); setDateIdx(0); setTimeIdx(0); setPick('from');
    }
  }, [selectedRoute?.id]);

  useEffect(() => {
    if (tripSheetOpen) {
      setVisible(true);
      Animated.parallel([
        Animated.spring(slideAnim, { toValue: 1, useNativeDriver: true, bounciness: 4 }),
        Animated.timing(overlayAnim, { toValue: 1, duration: 280, useNativeDriver: true }),
      ]).start();
    } else {
      Animated.parallel([
        Animated.timing(slideAnim, { toValue: 0, duration: 280, useNativeDriver: true }),
        Animated.timing(overlayAnim, { toValue: 0, duration: 240, useNativeDriver: true }),
      ]).start(() => setVisible(false));
    }
  }, [tripSheetOpen]);

  const translateY = slideAnim.interpolate({ inputRange: [0, 1], outputRange: [900, 0] });
  if (!visible || !selectedRoute) return null;
  const route = selectedRoute;
  const lo = Math.min(fromIdx, toIdx);
  const hi = Math.max(fromIdx, toIdx);
  const total = calcSegmentPrice(route, fromIdx, toIdx, pax);
  const valid = fromIdx !== toIdx;

  const pickStation = (idx: number) => {
    if (Platform.OS !== 'web') Haptics.selectionAsync();
    if (pick === 'from') {
      setFromIdx(idx);
      if (idx === toIdx) setToIdx(Math.min(route.path.length - 1, idx + 1));
      setPick('to');
    } else {
      if (idx === fromIdx) return;
      setToIdx(idx);
    }
  };

  return (
    <Modal transparent visible={visible} animationType="none" statusBarTranslucent>
      <View style={styles.root}>
        <Animated.View style={[styles.overlay, { opacity: overlayAnim }]}>
          <TouchableOpacity style={StyleSheet.absoluteFillObject} onPress={closeTripSheet} activeOpacity={1} />
        </Animated.View>
        <Animated.View style={[styles.sheet, { transform: [{ translateY }] }]}>
          <View style={styles.handle} />
          <ScrollView style={styles.scroll} contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
            <View style={styles.routeHeader}>
              <View style={styles.routeCodeBox}>
                <Text style={styles.routeCodeText}>{route.code}</Text>
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.routeNameText}>{route.name}</Text>
                <Text style={styles.routePathText}>{route.from} → {route.to}</Text>
              </View>
              <TouchableOpacity style={styles.heartBtn} activeOpacity={0.7}>
                <Ionicons name="heart-outline" size={16} color={c.ink} />
              </TouchableOpacity>
            </View>

            <View style={styles.section}>
              <SectionLabel icon={<Ionicons name="calendar-outline" size={14} color={c.inkSoft} />}>
                {t('travel_date')}
              </SectionLabel>
              <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.hScroll} contentContainerStyle={{ gap: 8, paddingRight: 4 }}>
                {DATES.map((d, i) => {
                  const active = i === dateIdx;
                  return (
                    <TouchableOpacity key={d.id} onPress={() => { setDateIdx(i); if (Platform.OS !== 'web') Haptics.selectionAsync(); }}
                      style={[styles.dateBtn, active ? styles.dateBtnActive : styles.dateBtnInactive]}>
                      <Text style={[styles.dateDayLabel, { opacity: active ? 0.85 : 0.7, color: active ? (c.isDark ? c.background : c.white) : c.ink }]}>{d.label}</Text>
                      <Text style={[styles.dateDay, { color: active ? (c.isDark ? c.background : c.white) : c.ink }]}>{d.day}</Text>
                    </TouchableOpacity>
                  );
                })}
              </ScrollView>
            </View>

            <View style={styles.section}>
              <SectionLabel icon={<Ionicons name="time-outline" size={14} color={c.inkSoft} />}>
                {t('departure')}
              </SectionLabel>
              <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.hScroll} contentContainerStyle={{ gap: 8, paddingRight: 4 }}>
                {TIMES.map((time, i) => (
                  <TouchableOpacity key={time} onPress={() => { setTimeIdx(i); if (Platform.OS !== 'web') Haptics.selectionAsync(); }}
                    style={[styles.timeBtn, i === timeIdx ? styles.timeBtnActive : styles.timeBtnInactive]}>
                    <Text style={[styles.timeText, { color: i === timeIdx ? (c.isDark ? c.background : c.white) : c.ink }]}>{time}</Text>
                  </TouchableOpacity>
                ))}
              </ScrollView>
            </View>

            <View style={styles.section}>
              <SectionLabel icon={<Ionicons name="location-outline" size={14} color={c.inkSoft} />}>
                {t('boarding_dropoff')}
              </SectionLabel>
              <View style={[gs, styles.pickTabWrap]}>
                {(['from', 'to'] as const).map((p) => {
                  const active = pick === p;
                  return (
                    <TouchableOpacity key={p} style={[styles.pickTab, active && styles.pickTabActive]} onPress={() => setPick(p)} activeOpacity={0.8}>
                      <Text style={[styles.pickTabText, { color: active ? (c.isDark ? c.background : c.white) : c.inkSoft }]} numberOfLines={1}>
                        {p === 'from' ? t('from') : t('to')} · {p === 'from' ? route.path[fromIdx].name : route.path[toIdx].name}
                      </Text>
                    </TouchableOpacity>
                  );
                })}
              </View>

              <View style={styles.timeline}>
                {route.path.map((s, i) => {
                  const inSegment = i >= lo && i <= hi;
                  const isFrom = i === fromIdx; const isTo = i === toIdx;
                  return (
                    <TouchableOpacity key={s.id} style={styles.timelineRow} onPress={() => pickStation(i)} activeOpacity={0.7}>
                      <View style={styles.timelineLeft}>
                        <View style={[styles.tlDot, isFrom || isTo ? styles.tlDotActive : inSegment ? styles.tlDotSeg : styles.tlDotInactive]} />
                        {i < route.path.length - 1 && (
                          <View style={[styles.tlLine, i >= lo && i < hi ? styles.tlLineActive : styles.tlLineInactive]} />
                        )}
                      </View>
                      <View style={styles.timelineRight}>
                        <View style={styles.timelineTextRow}>
                          <Text style={[styles.tlName, { color: inSegment ? c.ink : c.inkSoft }]}>{s.name}</Text>
                          {(isFrom || isTo) && (
                            <View style={styles.tlBadge}>
                              <Text style={styles.tlBadgeText}>{isFrom ? t('from') : t('to')}</Text>
                            </View>
                          )}
                        </View>
                        <Text style={styles.tlArea}>{s.area}</Text>
                      </View>
                    </TouchableOpacity>
                  );
                })}
              </View>
            </View>

            <View style={styles.section}>
              <SectionLabel icon={<Ionicons name="people-outline" size={14} color={c.inkSoft} />}>
                {t('passengers')}
              </SectionLabel>
              <View style={[gs, styles.paxRow]}>
                <View style={{ flex: 1 }}>
                  <Text style={styles.paxCount}>{pax} {pax === 1 ? t('pax_one') : t('pax_many')}</Text>
                  <Text style={styles.paxLimit}>{t('max_pax')}</Text>
                </View>
                <View style={styles.paxControls}>
                  <TouchableOpacity onPress={() => { setPax(Math.max(1, pax - 1)); if (Platform.OS !== 'web') Haptics.selectionAsync(); }} disabled={pax <= 1}
                    style={[styles.paxBtn, styles.paxBtnOutline, pax <= 1 && { opacity: 0.4 }]} activeOpacity={0.8}>
                    <Ionicons name="remove-outline" size={14} color={c.ink} />
                  </TouchableOpacity>
                  <Text style={styles.paxNum}>{pax}</Text>
                  <TouchableOpacity onPress={() => { setPax(Math.min(3, pax + 1)); if (Platform.OS !== 'web') Haptics.selectionAsync(); }} disabled={pax >= 3}
                    style={[styles.paxBtn, styles.paxBtnFilled, pax >= 3 && { opacity: 0.4 }]} activeOpacity={0.8}>
                    <Ionicons name="add-outline" size={14} color={c.isDark ? c.background : c.white} />
                  </TouchableOpacity>
                </View>
              </View>
            </View>

            <View style={[gs, styles.priceSummary]}>
              <View style={styles.priceIcon}>
                <Ionicons name="ticket-outline" size={20} color={c.isDark ? c.background : c.white} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.priceSegLabel}>{Math.max(1, hi - lo)} {hi - lo > 1 ? t('segments') : t('segment')} · {pax} {t('pax_one')}</Text>
                <Text style={styles.priceTotal}>{total} {t('egp')}</Text>
              </View>
              <View style={styles.ratingBox}>
                <Ionicons name="star" size={12} color={c.inkSoft} />
                <Text style={styles.ratingText}>4.9</Text>
              </View>
            </View>
          </ScrollView>

          <View style={styles.cta}>
            <TouchableOpacity disabled={!valid}
              onPress={() => { if (Platform.OS !== 'web') Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium); handleBook({ route, fromIdx, toIdx, passengers: pax, date: DATES[dateIdx].date, time: TIMES[timeIdx], price: total }); }}
              style={[styles.ctaBtn, !valid && { opacity: 0.4 }]} activeOpacity={0.9}>
              <Text style={styles.ctaBtnText}>{t('book')} · {total} {t('egp')}</Text>
              <Ionicons name="arrow-forward" size={16} color={c.isDark ? c.background : c.white} />
            </TouchableOpacity>
          </View>
        </Animated.View>
      </View>
    </Modal>
  );
}
