import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Platform } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '@/context/ThemeContext';

export function SectionHeader({ title, onMore }: { title: string; onMore?: () => void }) {
  const { colors: c, t } = useTheme();
  return (
    <View style={styles.sectionHeader}>
      <Text style={[styles.sectionTitle, { color: c.ink }]}>{title}</Text>
      {onMore && (
        <TouchableOpacity style={styles.seeAllBtn} onPress={onMore} activeOpacity={0.7}>
          <Text style={[styles.seeAllText, { color: c.inkSoft }]}>{t('see_all')}</Text>
          <Ionicons name="chevron-forward" size={12} color={c.inkSoft} />
        </TouchableOpacity>
      )}
    </View>
  );
}

export function SectionLabel({ children, icon }: { children: React.ReactNode; icon?: React.ReactNode }) {
  const { colors: c } = useTheme();
  return (
    <View style={styles.sectionLabel}>
      {icon}
      <Text style={[styles.sectionLabelText, { color: c.inkSoft }]}>{children}</Text>
    </View>
  );
}

export function MapMockView() {
  const { colors: c } = useTheme();
  const Svg = require('react-native-svg').Svg;
  const { Path, Circle, Rect, Defs, LinearGradient, Stop } = require('react-native-svg');
  const bg1 = c.isDark ? '#1a1a2e' : '#f2f4fb';
  const bg2 = c.isDark ? '#0f0f1e' : '#eaeaef';
  const stroke = c.isDark ? '#2c2c46' : '#d8d8e0';
  const dotFill = c.isDark ? '#2c2c46' : 'white';
  const dotCenter = c.isDark ? '#e8e8f2' : '#1e1e28';
  const locationFill = c.isDark ? 'rgba(232,232,242,0.12)' : 'rgba(30,30,40,0.12)';
  return (
    <View style={StyleSheet.absoluteFillObject}>
      <Svg viewBox="0 0 400 200" style={StyleSheet.absoluteFillObject}>
        <Defs>
          <LinearGradient id="mapbg" x1="0" y1="0" x2="0" y2="1">
            <Stop offset="0" stopColor={bg1} />
            <Stop offset="1" stopColor={bg2} />
          </LinearGradient>
        </Defs>
        <Rect width="400" height="200" fill="url(#mapbg)" />
        <Path d="M0,140 C100,120 160,160 260,130 C320,115 360,140 400,120" stroke={stroke} strokeWidth="1.2" fill="none" />
        <Path d="M30,30 L120,80 L210,40 L300,90 L390,60" stroke={stroke} strokeWidth="1.2" fill="none" />
        <Path d="M50,180 Q200,100 380,180" stroke={stroke} strokeWidth="1.2" fill="none" />
        {([[60, 90], [140, 130], [220, 70], [290, 120], [340, 80]] as [number, number][]).map(([x, y], i) => (
          <React.Fragment key={i}>
            <Circle cx={x} cy={y} r="9" fill={dotFill} />
            <Circle cx={x} cy={y} r="4" fill={dotCenter} />
          </React.Fragment>
        ))}
        <Circle cx="180" cy="110" r="14" fill={locationFill} />
        <Circle cx="180" cy="110" r="6" fill={dotCenter} />
      </Svg>
    </View>
  );
}

const styles = StyleSheet.create({
  sectionHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 28 },
  sectionTitle: { fontSize: 15, fontWeight: '600', letterSpacing: -0.3 },
  seeAllBtn: { flexDirection: 'row', alignItems: 'center', gap: 2 },
  seeAllText: { fontSize: 12, fontWeight: '500' },
  sectionLabel: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  sectionLabelText: { fontSize: 11, fontWeight: '600', textTransform: 'uppercase', letterSpacing: 1.2 },
});
