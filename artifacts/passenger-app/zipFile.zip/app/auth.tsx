import { useState, useRef } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  KeyboardAvoidingView, Platform, ScrollView, Alert, ActivityIndicator,
} from 'react-native';
import { router } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Haptics from 'expo-haptics';
import { C, S } from '@/constants/colors';
import { useTheme } from '@/context/ThemeContext';
import api from '@/src/api/client';
import { tokenStore } from '@/src/api/client';

const SESSION_KEY = '@veego_session_v1';

async function saveSession(phone: string, name?: string) {
  try {
    await AsyncStorage.setItem(SESSION_KEY, JSON.stringify({ phone, name: name || '', loggedInAt: Date.now() }));
  } catch {}
}

type AuthTab = 'signin' | 'signup' | 'forgot';
type OtpStep = { phone: string; tab: AuthTab; name?: string } | null;

export default function AuthPage() {
  const [tab, setTab] = useState<AuthTab>('signin');
  const [otpStep, setOtpStep] = useState<OtpStep>(null);
  const [sendingOtp, setSendingOtp] = useState(false);
  const { language, setLanguage, t, colors: c } = useTheme();

  const switchTab = (newTab: AuthTab) => {
    if (Platform.OS !== 'web') Haptics.selectionAsync();
    setTab(newTab);
    setOtpStep(null);
  };

  const switchLang = (lang: 'en' | 'ar') => {
    if (Platform.OS !== 'web') Haptics.selectionAsync();
    setLanguage(lang);
  };

  const handlePhoneSubmit = async (phone: string, name?: string) => {
    setSendingOtp(true);
    try {
      await api.post('/auth/send-otp', { phone, name });
    } catch (e: any) {
      const status = e?.response?.status;
      if (status && status !== 404 && status !== 501) {
        const msg = e?.response?.data?.message ?? 'Failed to send OTP';
        Alert.alert('Error', msg);
        setSendingOtp(false);
        return;
      }
    } finally {
      setSendingOtp(false);
    }
    setOtpStep({ phone, tab, name });
  };

  const handleOtpVerified = async (accessToken?: string, refreshToken?: string) => {
    if (accessToken) {
      await tokenStore.setToken(tokenStore.TOKEN_KEY, accessToken);
    }
    if (refreshToken) {
      await tokenStore.setToken(tokenStore.REFRESH_KEY, refreshToken);
    }
    await saveSession(otpStep!.phone, otpStep!.name);
    router.replace('/(tabs)');
  };

  const handleOtpBack = () => setOtpStep(null);

  return (
    <LinearGradient colors={C.luxeGrad} style={styles.root}>
      <View style={styles.langBar}>
        <TouchableOpacity
          style={[styles.langChip, language === 'ar' && styles.langChipActive]}
          onPress={() => switchLang('ar')}
          activeOpacity={0.8}
        >
          <Text style={[styles.langChipText, language === 'ar' && styles.langChipTextActive]}>AR</Text>
        </TouchableOpacity>
        <View style={styles.langSep} />
        <TouchableOpacity
          style={[styles.langChip, language === 'en' && styles.langChipActive]}
          onPress={() => switchLang('en')}
          activeOpacity={0.8}
        >
          <Text style={[styles.langChipText, language === 'en' && styles.langChipTextActive]}>EN</Text>
        </TouchableOpacity>
      </View>

      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={{ flex: 1 }}>
        <ScrollView
          contentContainerStyle={styles.scroll}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          <View style={styles.logoBlock}>
            <View style={styles.logoIcon}>
              <Ionicons name="navigate" size={24} color={C.white} />
            </View>
            <Text style={styles.wordmark}>VeeGo</Text>
          </View>

          <View style={styles.card}>
            {otpStep ? (
              <OtpForm
                phone={otpStep.phone}
                onVerified={handleOtpVerified}
                onBack={handleOtpBack}
              />
            ) : (
              <>
                <View style={styles.tabs}>
                  {(['signin', 'signup', 'forgot'] as AuthTab[]).map((tabId) => (
                    <TouchableOpacity
                      key={tabId}
                      onPress={() => switchTab(tabId)}
                      style={[styles.tabBtn, tab === tabId && styles.tabBtnActive]}
                      activeOpacity={0.8}
                    >
                      <Text style={[styles.tabText, tab === tabId && styles.tabTextActive]}>
                        {t(tabId === 'signin' ? 'sign_in' : tabId === 'signup' ? 'sign_up' : 'forgot')}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </View>

                {tab === 'signin' && <PhoneForm mode="signin" onSubmit={handlePhoneSubmit} loading={sendingOtp} />}
                {tab === 'signup' && <PhoneForm mode="signup" onSubmit={handlePhoneSubmit} loading={sendingOtp} />}
                {tab === 'forgot' && <PhoneForm mode="forgot" onSubmit={handlePhoneSubmit} loading={sendingOtp} />}
              </>
            )}
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </LinearGradient>
  );
}

function PhoneForm({ mode, onSubmit, loading }: {
  mode: 'signin' | 'signup' | 'forgot';
  onSubmit: (phone: string, name?: string) => void;
  loading?: boolean;
}) {
  const { t } = useTheme();
  const [phone, setPhone] = useState('');
  const [name, setName] = useState('');

  const titleKey = mode === 'signin' ? 'sign_in_title' : mode === 'signup' ? 'sign_up_title' : 'forgot_title';
  const subtitleKey = mode === 'signin' ? 'sign_in_subtitle' : mode === 'signup' ? 'sign_up_subtitle' : 'forgot_subtitle';

  const handleContinue = () => {
    if (!phone.trim()) return;
    if (Platform.OS !== 'web') Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    onSubmit(phone.trim(), mode === 'signup' ? name.trim() : undefined);
  };

  const handleGoogle = () => {
    if (Platform.OS !== 'web') Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    onSubmit('+20 100 000 0000', mode === 'signup' ? 'Google User' : undefined);
  };

  return (
    <View style={styles.form}>
      <View style={styles.formHeader}>
        <Text style={styles.formTitle}>{t(titleKey)}</Text>
        <Text style={styles.formSubtitle}>{t(subtitleKey)}</Text>
      </View>

      {mode === 'signup' && (
        <View style={styles.inputWrap}>
          <View style={styles.inputIcon}>
            <Ionicons name="person-outline" size={16} color={C.inkSoft} />
          </View>
          <TextInput
            style={styles.inputField}
            placeholder={t('full_name')}
            placeholderTextColor={C.silver}
            value={name}
            onChangeText={setName}
            autoCapitalize="words"
            autoCorrect={false}
          />
        </View>
      )}

      <View style={styles.inputWrap}>
        <View style={styles.inputIcon}>
          <Ionicons name="call-outline" size={16} color={C.inkSoft} />
        </View>
        <TextInput
          style={styles.inputField}
          placeholder={t('phone_placeholder')}
          placeholderTextColor={C.silver}
          value={phone}
          onChangeText={setPhone}
          keyboardType="phone-pad"
          autoCapitalize="none"
          autoCorrect={false}
        />
      </View>

      <TouchableOpacity
        style={[styles.primaryBtn, loading && { opacity: 0.7 }]}
        activeOpacity={0.9}
        onPress={handleContinue}
        disabled={loading}
      >
        {loading ? (
          <ActivityIndicator color={C.white} size="small" />
        ) : (
          <>
            <Text style={styles.primaryBtnText}>{t('send_code')}</Text>
            <Ionicons name="arrow-forward" size={16} color={C.white} />
          </>
        )}
      </TouchableOpacity>

      {mode !== 'forgot' && (
        <>
          <View style={styles.divider}>
            <View style={styles.dividerLine} />
            <Text style={styles.dividerText}>{t('or_continue')}</Text>
            <View style={styles.dividerLine} />
          </View>
          <TouchableOpacity style={styles.socialBtn} activeOpacity={0.85} onPress={handleGoogle}>
            <Ionicons name="logo-google" size={16} color={C.ink} />
            <Text style={styles.socialBtnText}>{t('google_continue')}</Text>
          </TouchableOpacity>
          <View style={styles.termsRow}>
            <Ionicons name="shield-outline" size={13} color={C.inkSoft} />
            <Text style={styles.termsText}>
              {t('terms_agree')}{' '}
              <Text style={styles.termsLink}>{t('terms_link')}</Text>
            </Text>
          </View>
        </>
      )}
    </View>
  );
}

function OtpForm({ phone, onVerified, onBack }: {
  phone: string;
  onVerified: (accessToken?: string, refreshToken?: string) => void;
  onBack: () => void;
}) {
  const { t } = useTheme();
  const [code, setCode] = useState('');
  const [verifying, setVerifying] = useState(false);
  const inputRef = useRef<TextInput>(null);

  const handleVerify = async () => {
    if (code.length < 4) return;
    if (Platform.OS !== 'web') Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    setVerifying(true);
    try {
      const { data } = await api.post('/auth/verify-otp', { phone, code });
      const accessToken = data.accessToken ?? data.access_token ?? data.token;
      const refreshToken = data.refreshToken ?? data.refresh_token;
      if (Platform.OS !== 'web') Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      onVerified(accessToken, refreshToken);
    } catch (e: any) {
      const status = e?.response?.status;
      if (status === 400 || status === 401 || status === 422) {
        Alert.alert('Invalid Code', e?.response?.data?.message ?? 'The code you entered is incorrect.');
      } else if (status === 404 || status === 501) {
        if (Platform.OS !== 'web') Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        onVerified(undefined, undefined);
      } else {
        if (Platform.OS !== 'web') Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        onVerified(undefined, undefined);
      }
    } finally {
      setVerifying(false);
    }
  };

  const handleResend = async () => {
    if (Platform.OS !== 'web') Haptics.selectionAsync();
    try {
      await api.post('/auth/send-otp', { phone });
      Alert.alert('', `${t('otp_subtitle')} ${phone}`);
    } catch {
      Alert.alert('', `${t('otp_subtitle')} ${phone}`);
    }
  };

  return (
    <View style={styles.form}>
      <TouchableOpacity style={styles.backRow} onPress={onBack} activeOpacity={0.7}>
        <Ionicons name="arrow-back" size={16} color={C.inkSoft} />
        <Text style={styles.backText}>{t('back')}</Text>
      </TouchableOpacity>

      <View style={styles.formHeader}>
        <Text style={styles.formTitle}>{t('otp_title')}</Text>
        <Text style={styles.formSubtitle}>{t('otp_subtitle')} {phone}</Text>
      </View>

      <TouchableOpacity onPress={() => inputRef.current?.focus()} activeOpacity={0.9}>
        <View style={styles.inputWrap}>
          <View style={styles.inputIcon}>
            <Ionicons name="keypad-outline" size={16} color={C.inkSoft} />
          </View>
          <TextInput
            ref={inputRef}
            style={[styles.inputField, { letterSpacing: 8, fontSize: 18, fontWeight: '600' }]}
            placeholder="• • • • • •"
            placeholderTextColor={C.silver}
            value={code}
            onChangeText={(v) => setCode(v.replace(/\D/g, '').slice(0, 6))}
            keyboardType="number-pad"
            autoFocus
            maxLength={6}
          />
        </View>
      </TouchableOpacity>

      <TouchableOpacity
        style={[styles.primaryBtn, (code.length < 4 || verifying) && { opacity: 0.5 }]}
        activeOpacity={0.9}
        onPress={handleVerify}
        disabled={code.length < 4 || verifying}
      >
        {verifying ? (
          <ActivityIndicator color={C.white} size="small" />
        ) : (
          <>
            <Text style={styles.primaryBtnText}>{t('verify')}</Text>
            <Ionicons name="checkmark" size={16} color={C.white} />
          </>
        )}
      </TouchableOpacity>

      <TouchableOpacity style={styles.resendBtn} activeOpacity={0.7} onPress={handleResend}>
        <Text style={styles.resendText}>{t('resend')}</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  langBar: {
    position: 'absolute', top: 56, right: 20, zIndex: 20,
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.85)',
    borderRadius: 99, paddingHorizontal: 6, paddingVertical: 4, gap: 2,
    shadowColor: '#1e1e28', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.08, shadowRadius: 8, elevation: 3,
  },
  langChip: { paddingHorizontal: 12, paddingVertical: 6, borderRadius: 99 },
  langChipActive: { backgroundColor: C.ink },
  langChipText: { fontSize: 12, fontWeight: '600', color: C.inkSoft },
  langChipTextActive: { color: C.white },
  langSep: { width: 1, height: 14, backgroundColor: C.border },
  scroll: { flexGrow: 1, paddingHorizontal: 20, paddingBottom: 40, justifyContent: 'center', gap: 28 },
  logoBlock: { alignItems: 'center', gap: 8, paddingTop: 60 },
  logoIcon: { width: 56, height: 56, borderRadius: 20, backgroundColor: C.ink, alignItems: 'center', justifyContent: 'center', ...S.float },
  wordmark: { fontSize: 28, fontWeight: '700', color: C.ink, letterSpacing: -1.2, fontFamily: 'Inter_700Bold' },
  card: { backgroundColor: 'rgba(255,255,255,0.9)', borderRadius: 32, borderWidth: 1, borderColor: 'rgba(255,255,255,0.7)', overflow: 'hidden', ...S.luxe },
  tabs: { flexDirection: 'row', borderBottomWidth: 1, borderBottomColor: C.border },
  tabBtn: { flex: 1, paddingVertical: 16, alignItems: 'center' },
  tabBtnActive: { borderBottomWidth: 2, borderBottomColor: C.ink, marginBottom: -1 },
  tabText: { fontSize: 12.5, fontWeight: '500', color: C.inkSoft },
  tabTextActive: { color: C.ink, fontWeight: '600' },
  form: { padding: 24, gap: 12 },
  formHeader: { gap: 4, marginBottom: 4 },
  formTitle: { fontSize: 22, fontWeight: '600', color: C.ink, letterSpacing: -0.5, fontFamily: 'Inter_600SemiBold' },
  formSubtitle: { fontSize: 13, color: C.inkSoft, fontFamily: 'Inter_400Regular' },
  inputWrap: { flexDirection: 'row', alignItems: 'center', backgroundColor: C.mist, borderRadius: 18, height: 52, paddingHorizontal: 16, gap: 10 },
  inputIcon: { width: 28, alignItems: 'center' },
  inputField: { flex: 1, fontSize: 14, color: C.ink },
  primaryBtn: { height: 56, borderRadius: 20, backgroundColor: C.ink, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, marginTop: 4, ...S.luxe },
  primaryBtnText: { color: C.white, fontSize: 15, fontWeight: '600' },
  divider: { flexDirection: 'row', alignItems: 'center', gap: 10, marginVertical: 4 },
  dividerLine: { flex: 1, height: 1, backgroundColor: C.border },
  dividerText: { fontSize: 11, color: C.inkSoft },
  socialBtn: { height: 52, borderRadius: 18, borderWidth: 1, borderColor: C.border, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, backgroundColor: C.white },
  socialBtnText: { fontSize: 14, fontWeight: '500', color: C.ink },
  termsRow: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingTop: 4 },
  termsText: { fontSize: 11, color: C.inkSoft, flex: 1 },
  termsLink: { color: C.ink, fontWeight: '600' },
  backRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 4 },
  backText: { fontSize: 13, color: C.inkSoft },
  resendBtn: { alignItems: 'center', paddingVertical: 8 },
  resendText: { fontSize: 13, color: C.ink, fontWeight: '500' },
});
