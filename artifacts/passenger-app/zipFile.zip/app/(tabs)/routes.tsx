import { useState, useMemo } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, Platform } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import * as Haptics from 'expo-haptics';
import { routes } from '@/constants/data';
import { RouteCard } from '@/components/RouteCard';
import { useBooking } from '@/context/BookingContext';
import { useTheme } from '@/context/ThemeContext';
import { ThemeColors } from '@/constants/colors';

const FILTERS = ['All lines', 'L01', 'L02', 'L03', 'L04'];

function makeStyles(c: ThemeColors) {
  return StyleSheet.create({
    header: {
      flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between',
      paddingHorizontal: 20, paddingBottom: 12,
    },
    headerTitle: { fontSize: 26, fontWeight: '700', color: c.ink, letterSpacing: -0.8, fontFamily: 'Inter_700Bold' },
    headerSub: { fontSize: 12, color: c.inkSoft, marginTop: 2 },
    iconBtn: { width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center' },
    filterScroll: { flexGrow: 0, marginBottom: 16 },
    filterChip: { height: 38, paddingHorizontal: 16, borderRadius: 99, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
    filterChipActive: { backgroundColor: c.ink, borderColor: c.ink },
    filterChipInactive: { backgroundColor: c.white, borderColor: c.border },
    filterText: { fontSize: 13, fontWeight: '500' },
    filterTextActive: { color: c.isDark ? c.background : c.white },
    filterTextInactive: { color: c.inkSoft },
    list: { paddingHorizontal: 20, gap: 12 },
  });
}

export default function RoutesScreen() {
  const insets = useSafeAreaInsets();
  const top = Platform.OS === 'web' ? 60 : insets.top;
  const [activeFilter, setActiveFilter] = useState('All lines');
  const { openRoute } = useBooking();
  const { colors: c, glassStyle: gs, t } = useTheme();
  const styles = useMemo(() => makeStyles(c), [c]);

  const filtered = activeFilter === 'All lines'
    ? routes
    : routes.filter((r) => r.code === activeFilter);

  const allFilters = [t('all_lines'), ...FILTERS.slice(1)];

  return (
    <LinearGradient colors={c.luxeGrad} style={{ flex: 1 }}>
      <View style={[styles.header, { paddingTop: top + 12 }]}>
        <View>
          <Text style={styles.headerTitle}>{t('routes_title')}</Text>
          <Text style={styles.headerSub}>{routes.length} {t('lines_available')}</Text>
        </View>
        <TouchableOpacity style={[gs, styles.iconBtn]} activeOpacity={0.8}>
          <Ionicons name="search-outline" size={16} color={c.ink} />
        </TouchableOpacity>
      </View>

      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={styles.filterScroll}
        contentContainerStyle={{ paddingHorizontal: 20, gap: 8 }}
      >
        {allFilters.map((f, i) => {
          const raw = i === 0 ? 'All lines' : FILTERS[i];
          const active = activeFilter === raw;
          return (
            <TouchableOpacity
              key={raw}
              style={[styles.filterChip, active ? styles.filterChipActive : styles.filterChipInactive]}
              onPress={() => { setActiveFilter(raw); if (Platform.OS !== 'web') Haptics.selectionAsync(); }}
              activeOpacity={0.8}
            >
              <Text style={[styles.filterText, active ? styles.filterTextActive : styles.filterTextInactive]}>
                {f}
              </Text>
            </TouchableOpacity>
          );
        })}
      </ScrollView>

      <ScrollView style={{ flex: 1 }} contentContainerStyle={styles.list} showsVerticalScrollIndicator={false}>
        {filtered.map((r) => (
          <RouteCard key={r.id} route={r} onPress={() => openRoute(r)} />
        ))}
        <View style={{ height: 100 }} />
      </ScrollView>
    </LinearGradient>
  );
}
