import { useRef, useEffect, useState } from 'react';
import { Tabs } from 'expo-router';
import { View, Text, TouchableOpacity, StyleSheet, Platform, Animated } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import type { BottomTabBarProps } from '@react-navigation/bottom-tabs';
import { useTheme } from '@/context/ThemeContext';
import { S } from '@/constants/colors';

const TAB_ITEMS = [
  { name: 'index',     labelKey: 'home'      as const, icon: 'home-outline',        iconActive: 'home' },
  { name: 'trips',     labelKey: 'trips'     as const, icon: 'ticket-outline',      iconActive: 'ticket' },
  { name: 'favorites', labelKey: 'favorites' as const, icon: 'heart-outline',       iconActive: 'heart' },
  { name: 'wallet',    labelKey: 'wallet'    as const, icon: 'wallet-outline',      iconActive: 'wallet' },
  { name: 'profile',   labelKey: 'profile'   as const, icon: 'person-outline',      iconActive: 'person' },
];

function VeeGoTabBar({ state, navigation }: BottomTabBarProps) {
  const insets = useSafeAreaInsets();
  const bottom = Platform.OS === 'web' ? 24 : insets.bottom + 8;
  const { colors: c, t } = useTheme();

  const tabWidths = useRef<number[]>([]);
  const tabOffsets = useRef<number[]>([]);
  const pillX = useRef(new Animated.Value(0)).current;
  const pillW = useRef(new Animated.Value(0)).current;
  const [pillReady, setPillReady] = useState(false);

  const animatePill = (index: number) => {
    const x = tabOffsets.current[index];
    const w = tabWidths.current[index];
    if (x !== undefined && w > 0) {
      Animated.spring(pillX, {
        toValue: x,
        useNativeDriver: false,
        damping: 22,
        stiffness: 220,
        mass: 0.75,
      }).start();
      Animated.spring(pillW, {
        toValue: w,
        useNativeDriver: false,
        damping: 22,
        stiffness: 220,
        mass: 0.75,
      }).start();
    }
  };

  useEffect(() => {
    if (pillReady) {
      animatePill(state.index);
    }
  }, [state.index, pillReady]);

  const handleLayout = (i: number, x: number, w: number) => {
    tabWidths.current[i] = w;
    tabOffsets.current[i] = x;
    const allSet =
      tabWidths.current.length === TAB_ITEMS.length &&
      tabOffsets.current.length === TAB_ITEMS.length &&
      tabWidths.current.every((v) => v > 0);
    if (allSet) {
      if (!pillReady) {
        pillX.setValue(tabOffsets.current[state.index]);
        pillW.setValue(tabWidths.current[state.index]);
        setPillReady(true);
      } else {
        animatePill(state.index);
      }
    }
  };

  return (
    <View style={[styles.navOuter, { paddingBottom: bottom }]}>
      <View
        style={[
          styles.navInner,
          S.float,
          {
            backgroundColor: c.isDark ? 'rgba(26,28,50,0.97)' : 'rgba(255,255,255,0.94)',
            borderWidth: 1,
            borderColor: c.isDark ? 'rgba(90,95,160,0.2)' : 'rgba(255,255,255,0.7)',
          },
        ]}
      >
        {pillReady && (
          <Animated.View
            pointerEvents="none"
            style={[
              styles.activePill,
              {
                backgroundColor: c.ink,
                left: pillX,
                width: pillW,
              },
            ]}
          />
        )}
        {TAB_ITEMS.map((item, i) => {
          const active = state.index === i;
          return (
            <TouchableOpacity
              key={item.name}
              style={styles.navItem}
              activeOpacity={0.8}
              onPress={() => navigation.navigate(item.name)}
              onLayout={(e) => {
                const { x, width } = e.nativeEvent.layout;
                handleLayout(i, x, width);
              }}
            >
              <Ionicons
                name={(active ? item.iconActive : item.icon) as any}
                size={17}
                color={active ? (c.isDark ? c.background : c.white) : c.inkSoft}
                style={{ zIndex: 2 }}
              />
              <Text
                style={[
                  styles.navLabel,
                  { color: active ? (c.isDark ? c.background : c.white) : c.inkSoft, zIndex: 2 },
                ]}
                numberOfLines={1}
              >
                {t(item.labelKey)}
              </Text>
            </TouchableOpacity>
          );
        })}
      </View>
    </View>
  );
}

export default function TabLayout() {
  return (
    <Tabs
      tabBar={(props) => <VeeGoTabBar {...props} />}
      screenOptions={{ headerShown: false }}
    >
      <Tabs.Screen name="index" />
      <Tabs.Screen name="trips" />
      <Tabs.Screen name="favorites" />
      <Tabs.Screen name="wallet" />
      <Tabs.Screen name="profile" />
      <Tabs.Screen name="car" options={{ href: null }} />
      <Tabs.Screen name="routes" options={{ href: null }} />
    </Tabs>
  );
}

const styles = StyleSheet.create({
  navOuter: {
    position: 'absolute', bottom: 0, left: 0, right: 0,
    paddingHorizontal: 10, paddingTop: 4,
  },
  navInner: {
    flexDirection: 'row', borderRadius: 30,
    paddingVertical: 6, paddingHorizontal: 4, gap: 0,
  },
  navItem: {
    flex: 1, alignItems: 'center', justifyContent: 'center',
    paddingVertical: 8, borderRadius: 20, gap: 3,
    zIndex: 2,
  },
  activePill: {
    position: 'absolute', top: 6, bottom: 6, borderRadius: 20, zIndex: 1,
  },
  navLabel: { fontSize: 9, fontWeight: '500', lineHeight: 12 },
});
