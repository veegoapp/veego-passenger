import { useState, useEffect, useRef, useCallback } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, Animated, Easing,
  ScrollView, TextInput, Platform, Alert, Dimensions,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import * as Haptics from 'expo-haptics';
import * as Location from 'expo-location';
import { C, S, glassStyle } from '@/constants/colors';
import { useTheme } from '@/context/ThemeContext';

// Safe haptics wrapper — expo-haptics is no-op on web
const haptic = {
  selection: () => { if (Platform.OS !== 'web') Haptics.selectionAsync(); },
  impact: (style = Haptics.ImpactFeedbackStyle.Medium) => { if (Platform.OS !== 'web') Haptics.impactAsync(style); },
  notify: (type: Haptics.NotificationFeedbackType) => { if (Platform.OS !== 'web') Haptics.notificationAsync(type); },
};

const { width: SW } = Dimensions.get('window');
const MAP_H = 270;

const GEOFENCE = { minLat: 22.5, maxLat: 28.5, minLon: 25.0, maxLon: 33.5 };
function isInGeofence(lat: number, lon: number) {
  return lat >= GEOFENCE.minLat && lat <= GEOFENCE.maxLat
    && lon >= GEOFENCE.minLon && lon <= GEOFENCE.maxLon;
}

const WG_PLACES = [
  'Kharga Central Station',
  'Al Nasser Square',
  'Al Mochtat',
  'Hiraiz District',
  'Al Qasaba',
  'Baris Town Center',
  'Al Qasr Village',
  'Dakhla Medical Center',
  'New Valley University',
  'Al Farafra Hospital',
  'Kharga Market',
  'Government Complex',
  'Al Kharga Airport',
  'Tiba Mall',
];

const MOCK_DRIVERS = [
  { name: 'Ahmed Hassan', plate: 'و ح ج ٢٣٤٥', rating: 4.9, car: 'White Hyundai Accent', initials: 'AH' },
  { name: 'Mohamed Ali', plate: 'ن م ل ١٧٨٩', rating: 4.8, car: 'Silver Kia Pegas', initials: 'MA' },
  { name: 'Omar Saleh', plate: 'ع ب ك ٩٠١٢', rating: 4.7, car: 'Black Toyota Yaris', initials: 'OS' },
];

function calcPrice(from: string, to: string) {
  const h = (from + to).split('').reduce((a, c) => a + c.charCodeAt(0), 0);
  return 15 + (h % 60);
}

type Phase = 'request' | 'finding' | 'active' | 'arrived';

const USER_X = SW * 0.46;
const USER_Y = MAP_H * 0.54;
const DEST_X = SW * 0.68;
const DEST_Y = MAP_H * 0.25;

function SearchRing({ anim }: { anim: Animated.Value }) {
  const scale = anim.interpolate({ inputRange: [0, 1], outputRange: [0, 3.8] });
  const opacity = anim.interpolate({ inputRange: [0, 0.25, 1], outputRange: [0, 0.55, 0] });
  return (
    <Animated.View
      style={[
        styles.searchRing,
        { left: USER_X - 28, top: USER_Y - 28, transform: [{ scale }], opacity },
      ]}
    />
  );
}

function RideMap({ phase }: { phase: Phase }) {
  const pulseAnim = useRef(new Animated.Value(0)).current;
  const ring1 = useRef(new Animated.Value(0)).current;
  const ring2 = useRef(new Animated.Value(0)).current;
  const ring3 = useRef(new Animated.Value(0)).current;
  const driverX = useRef(new Animated.Value((SW - 32) * 0.74)).current;
  const driverY = useRef(new Animated.Value(MAP_H * 0.26)).current;

  useEffect(() => {
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, { toValue: 1, duration: 1300, useNativeDriver: true }),
        Animated.timing(pulseAnim, { toValue: 0, duration: 1300, useNativeDriver: true }),
      ])
    );
    loop.start();
    return () => loop.stop();
  }, []);

  useEffect(() => {
    if (phase !== 'finding') return;
    function makeRing(a: Animated.Value, delay: number) {
      return Animated.loop(
        Animated.sequence([
          Animated.delay(delay),
          Animated.timing(a, { toValue: 1, duration: 2200, easing: Easing.out(Easing.quad), useNativeDriver: true }),
          Animated.timing(a, { toValue: 0, duration: 0, useNativeDriver: true }),
        ])
      );
    }
    driverX.setValue((SW - 32) * 0.74);
    driverY.setValue(MAP_H * 0.26);
    const l1 = makeRing(ring1, 0);
    const l2 = makeRing(ring2, 730);
    const l3 = makeRing(ring3, 1460);
    l1.start(); l2.start(); l3.start();
    Animated.timing(driverX, {
      toValue: USER_X - 10,
      duration: 10000,
      easing: Easing.inOut(Easing.quad),
      useNativeDriver: false,
    }).start();
    Animated.timing(driverY, {
      toValue: USER_Y - 10,
      duration: 10000,
      easing: Easing.inOut(Easing.quad),
      useNativeDriver: false,
    }).start();
    return () => { l1.stop(); l2.stop(); l3.stop(); };
  }, [phase]);

  const pulseScale = pulseAnim.interpolate({ inputRange: [0, 1], outputRange: [1, 2.1] });
  const pulseOpacity = pulseAnim.interpolate({ inputRange: [0, 1], outputRange: [0.45, 0] });

  return (
    <View style={styles.mapContainer}>
      <LinearGradient colors={['#1b1f38', '#232847']} style={StyleSheet.absoluteFillObject} />

      {[0.22, 0.44, 0.66, 0.88].map((f) => (
        <View key={`h${f}`} style={[styles.gridLine, { top: MAP_H * f, width: '100%', height: 1 }]} />
      ))}
      {[0.18, 0.36, 0.54, 0.72, 0.88].map((f) => (
        <View key={`v${f}`} style={[styles.gridLine, { left: SW * f, height: MAP_H, width: 1 }]} />
      ))}

      <View style={[styles.road, { top: MAP_H * 0.38, width: '100%', height: 6 }]} />
      <View style={[styles.road, { top: MAP_H * 0.68, width: '65%', height: 4 }]} />
      <View style={[styles.road, { left: SW * 0.44, height: '100%', width: 6 }]} />
      <View style={[styles.road, { left: SW * 0.7, height: '55%', width: 4, top: 0 }]} />

      {(phase === 'active' || phase === 'finding') && (
        <View
          style={[
            styles.routeLine,
            {
              left: USER_X,
              top: DEST_Y,
              width: DEST_X - USER_X,
              height: USER_Y - DEST_Y,
            },
          ]}
        />
      )}

      {(phase === 'request' || phase === 'active' || phase === 'finding') && (
        <View style={[styles.destMarker, { left: DEST_X - 11, top: DEST_Y - 24 }]}>
          <Ionicons name="location" size={22} color={C.accentMint} />
        </View>
      )}

      {(phase === 'finding' || phase === 'active') && (
        <Animated.View
          style={[
            styles.driverDot,
            { left: driverX, top: driverY },
          ]}
        >
          <Ionicons name="car" size={13} color={C.white} />
        </Animated.View>
      )}

      {phase === 'finding' && (
        <>
          <SearchRing anim={ring1} />
          <SearchRing anim={ring2} />
          <SearchRing anim={ring3} />
        </>
      )}

      <Animated.View
        style={[
          styles.userPulse,
          { left: USER_X - 16, top: USER_Y - 16, transform: [{ scale: pulseScale }], opacity: pulseOpacity },
        ]}
      />
      <View style={[styles.userDot, { left: USER_X - 9, top: USER_Y - 9 }]} />

      <View style={styles.geofenceBadge}>
        <Ionicons name="shield-checkmark" size={10} color={C.accentMint} />
        <Text style={styles.geofenceText}>Wadi El Gedid only</Text>
      </View>
    </View>
  );
}

function PlacePicker({
  label, value, onSelect,
}: { label: string; value: string; onSelect: (p: string) => void }) {
  const { t } = useTheme();
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState('');
  const filtered = WG_PLACES.filter((p) =>
    p.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <View style={{ zIndex: open ? 20 : 1 }}>
      <TouchableOpacity
        style={[glassStyle, styles.placeRow]}
        onPress={() => { setOpen((o) => !o); haptic.selection(); }}
        activeOpacity={0.8}
      >
        <View style={[styles.placeDot, value ? styles.placeDotActive : {}]} />
        <Text style={[styles.placeText, !value && styles.placeTextPlaceholder]}>
          {value || label}
        </Text>
        <Ionicons name={open ? 'chevron-up' : 'chevron-down'} size={14} color={C.inkSoft} />
      </TouchableOpacity>
      {open && (
        <View style={[styles.dropdown, S.float]}>
          <View style={styles.dropSearch}>
            <Ionicons name="search-outline" size={13} color={C.inkSoft} />
            <TextInput
              style={styles.dropInput}
              placeholder={t('search_wadi')}
              placeholderTextColor={C.inkSoft}
              value={query}
              onChangeText={setQuery}
              autoFocus
            />
          </View>
          <ScrollView style={{ maxHeight: 190 }} showsVerticalScrollIndicator={false}>
            {filtered.map((p) => (
              <TouchableOpacity
                key={p}
                style={styles.dropItem}
                onPress={() => { onSelect(p); setOpen(false); setQuery(''); haptic.selection(); }}
                activeOpacity={0.7}
              >
                <Ionicons name="location-outline" size={13} color={C.inkSoft} />
                <Text style={styles.dropItemText}>{p}</Text>
              </TouchableOpacity>
            ))}
            {filtered.length === 0 && (
              <Text style={styles.dropEmpty}>{t('no_locations')}</Text>
            )}
          </ScrollView>
        </View>
      )}
    </View>
  );
}

export default function CarScreen() {
  const insets = useSafeAreaInsets();
  const top = Platform.OS === 'web' ? 60 : insets.top;
  const { t } = useTheme();

  const [phase, setPhase] = useState<Phase>('request');
  const [pickup, setPickup] = useState('');
  const [dropoff, setDropoff] = useState('');
  const [outsideZone, setOutsideZone] = useState(false);
  const driverIdx = useRef(Math.floor(Math.random() * MOCK_DRIVERS.length)).current;
  const driver = MOCK_DRIVERS[driverIdx];
  const [eta, setEta] = useState(420);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const price = pickup && dropoff ? calcPrice(pickup, dropoff) : null;

  useEffect(() => {
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, []);

  const startFinding = useCallback(() => {
    if (!pickup || !dropoff) {
      Alert.alert('Select locations', 'Please select both pickup and drop-off.');
      return;
    }
    haptic.impact();
    setEta(420);
    setPhase('finding');
    timerRef.current = setInterval(() => {
      setEta((s) => {
        if (s <= 8) {
          clearInterval(timerRef.current!);
          timerRef.current = null;
          setPhase('active');
          return 0;
        }
        return s - 8;
      });
    }, 400);
  }, [pickup, dropoff]);

  const cancelRide = useCallback(() => {
    if (timerRef.current) { clearInterval(timerRef.current); timerRef.current = null; }
    haptic.notify(Haptics.NotificationFeedbackType.Warning);
    setPhase('request');
  }, []);

  const confirmArrival = useCallback(() => {
    if (timerRef.current) { clearInterval(timerRef.current); timerRef.current = null; }
    haptic.notify(Haptics.NotificationFeedbackType.Success);
    setPhase('arrived');
  }, []);

  const resetRide = useCallback(() => {
    setPhase('request');
    setPickup('');
    setDropoff('');
  }, []);

  function fmtEta(s: number) {
    const m = Math.floor(s / 60);
    const ss = s % 60;
    return `${m}:${String(ss).padStart(2, '0')}`;
  }

  if (phase === 'arrived') {
    return (
      <LinearGradient colors={C.luxeSoftGrad} style={{ flex: 1 }}>
        <View style={[styles.arrivedScreen, { paddingTop: top + 40 }]}>
          <LinearGradient colors={[C.accentMint, '#3daa80']} style={styles.successCircle}>
            <Ionicons name="checkmark" size={38} color={C.white} />
          </LinearGradient>
          <Text style={styles.arrivedTitle}>{t('trip_complete')}</Text>
          <Text style={styles.arrivedSub}>{pickup}  →  {dropoff}</Text>

          <View style={[glassStyle, styles.arrivedCard, S.luxe]}>
            <View style={styles.arrivedRow}>
              <View style={styles.driverAvatarSm}>
                <Text style={styles.driverAvatarSmText}>{driver.initials}</Text>
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.arrivedDriverName}>{driver.name}</Text>
                <Text style={styles.arrivedDriverCar}>{driver.car} · {driver.plate}</Text>
              </View>
              <View style={styles.ratingBadge}>
                <Ionicons name="star" size={11} color="#f5a623" />
                <Text style={styles.ratingText}>{driver.rating}</Text>
              </View>
            </View>
            <View style={styles.arrivedDivider} />
            <View style={styles.arrivedPayRow}>
              <Ionicons name="cash-outline" size={16} color={C.inkSoft} />
              <Text style={styles.arrivedPayText}>{t('cash_paid').replace('{p}', String(price))}</Text>
              <View style={styles.paidBadge}>
                <Text style={styles.paidBadgeText}>{t('cash_only')}</Text>
              </View>
            </View>
          </View>

          <TouchableOpacity style={styles.primaryBtn} onPress={resetRide} activeOpacity={0.85}>
            <Ionicons name="add-circle-outline" size={16} color={C.white} />
            <Text style={styles.primaryBtnText}>{t('book_another')}</Text>
          </TouchableOpacity>
        </View>
      </LinearGradient>
    );
  }

  return (
    <LinearGradient colors={C.luxeSoftGrad} style={{ flex: 1 }}>
      <View style={{ paddingTop: top + 8, paddingHorizontal: 20, paddingBottom: 8 }}>
        <Text style={styles.screenTitle}>Car</Text>
        <Text style={styles.screenSub}>Ride-hailing · Wadi El Gedid</Text>
      </View>

      <RideMap phase={phase} />

      {outsideZone && phase === 'request' && (
        <View style={styles.zoneBanner}>
          <Ionicons name="warning-outline" size={13} color={C.badge} />
          <Text style={styles.zoneBannerText}>
            Outside service area — rides available in Wadi El Gedid only.
          </Text>
        </View>
      )}

      {phase === 'request' && (
        <ScrollView
          style={{ flex: 1 }}
          contentContainerStyle={styles.sheet}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          <View style={styles.sheetHandle} />
          <Text style={styles.sheetTitle}>Book a ride</Text>

          <View style={{ gap: 10, marginTop: 16 }}>
            <PlacePicker label="📍  Pickup location" value={pickup} onSelect={setPickup} />
            <PlacePicker label="🏁  Where to?" value={dropoff} onSelect={setDropoff} />
          </View>

          {price !== null && (
            <View style={[glassStyle, styles.priceCard, S.luxe]}>
              <View style={styles.priceRow}>
                <View style={styles.priceIcon}>
                  <Ionicons name="car-outline" size={17} color={C.ink} />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.priceLabel}>Economy ride</Text>
                  <Text style={styles.priceSub}>1–4 passengers</Text>
                </View>
                <Text style={styles.priceAmount}>EGP {price}</Text>
              </View>
              <View style={styles.priceMeta}>
                <Ionicons name="time-outline" size={11} color={C.inkSoft} />
                <Text style={styles.priceMetaText}>~{Math.ceil(price / 12)} min away</Text>
                <View style={styles.priceSep} />
                <Ionicons name="cash-outline" size={11} color={C.inkSoft} />
                <Text style={styles.priceMetaText}>Cash only</Text>
              </View>
            </View>
          )}

          <TouchableOpacity
            style={[styles.primaryBtn, !price && styles.primaryBtnDisabled]}
            onPress={startFinding}
            activeOpacity={0.85}
          >
            <Ionicons name="navigate" size={15} color={C.white} />
            <Text style={styles.primaryBtnText}>Confirm ride</Text>
          </TouchableOpacity>

          <View style={{ height: 100 }} />
        </ScrollView>
      )}

      {phase === 'finding' && (
        <View style={styles.sheet}>
          <View style={styles.sheetHandle} />
          <View style={styles.findingHeader}>
            <View>
              <Text style={styles.sheetTitle}>{t('finding_driver')}</Text>
              <Text style={styles.sheetSub}>
                {eta > 0 ? `${t('arrives_in')} ${fmtEta(eta)}` : t('driver_arriving')}
              </Text>
            </View>
            <View style={styles.etaBubble}>
              <Text style={styles.etaText}>{fmtEta(eta)}</Text>
            </View>
          </View>

          <View style={[glassStyle, styles.driverCard, S.luxe]}>
            <View style={styles.driverAvatar}>
              <Text style={styles.driverAvatarText}>{driver.initials}</Text>
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.driverName}>{driver.name}</Text>
              <Text style={styles.driverCarText}>{driver.car}</Text>
              <View style={styles.ratingRow}>
                <Ionicons name="star" size={11} color="#f5a623" />
                <Text style={styles.ratingText}>{driver.rating}</Text>
              </View>
            </View>
            <View style={styles.plateBadge}>
              <Text style={styles.plateText}>{driver.plate}</Text>
            </View>
          </View>

          <View style={styles.tripSummaryRow}>
            <View style={[styles.tripDot, { backgroundColor: C.ink }]} />
            <Text style={styles.tripStopText} numberOfLines={1}>{pickup}</Text>
            <Ionicons name="arrow-forward" size={11} color={C.inkSoft} style={{ marginHorizontal: 6 }} />
            <View style={[styles.tripDot, { backgroundColor: C.accentMint }]} />
            <Text style={styles.tripStopText} numberOfLines={1}>{dropoff}</Text>
          </View>

          <TouchableOpacity style={styles.cancelBtn} onPress={cancelRide} activeOpacity={0.8}>
            <Text style={styles.cancelBtnText}>{t('cancel_ride')}</Text>
          </TouchableOpacity>
        </View>
      )}

      {phase === 'active' && (
        <View style={styles.sheet}>
          <View style={styles.sheetHandle} />
          <View style={styles.findingHeader}>
            <View>
              <Text style={styles.sheetTitle}>{t('on_your_way')}</Text>
              <Text style={styles.sheetSub}>{dropoff}</Text>
            </View>
            <LinearGradient colors={[C.accentMint, '#3daa80']} style={styles.liveBadge}>
              <Text style={styles.liveBadgeText}>LIVE</Text>
            </LinearGradient>
          </View>

          <View style={[glassStyle, styles.driverCard, S.luxe]}>
            <View style={styles.driverAvatar}>
              <Text style={styles.driverAvatarText}>{driver.initials}</Text>
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.driverName}>{driver.name}</Text>
              <Text style={styles.driverCarText}>{driver.car} · {driver.plate}</Text>
            </View>
            <View style={styles.tripPriceBadge}>
              <Text style={styles.tripPriceLabel}>EGP</Text>
              <Text style={styles.tripPriceAmount}>{price}</Text>
            </View>
          </View>

          <View style={[glassStyle, styles.routeCard, S.luxe]}>
            <View style={styles.routeRow}>
              <View style={[styles.tripDot, { backgroundColor: C.ink }]} />
              <Text style={styles.routeText}>{pickup}</Text>
            </View>
            <View style={styles.routeConnector} />
            <View style={styles.routeRow}>
              <View style={[styles.tripDot, { backgroundColor: C.accentMint }]} />
              <Text style={styles.routeText}>{dropoff}</Text>
            </View>
            <View style={styles.routePayRow}>
              <Ionicons name="cash-outline" size={12} color={C.inkSoft} />
              <Text style={styles.routePayText}>Cash · EGP {price} at destination</Text>
            </View>
          </View>

          <TouchableOpacity style={styles.primaryBtn} onPress={confirmArrival} activeOpacity={0.85}>
            <Ionicons name="checkmark-circle" size={15} color={C.white} />
            <Text style={styles.primaryBtnText}>I have arrived</Text>
          </TouchableOpacity>
        </View>
      )}
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  screenTitle: { fontSize: 26, fontWeight: '700', color: C.ink, letterSpacing: -0.8 },
  screenSub: { fontSize: 12, color: C.inkSoft, marginTop: 2 },

  mapContainer: {
    height: MAP_H,
    overflow: 'hidden',
    position: 'relative',
  },
  gridLine: {
    position: 'absolute',
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  road: {
    position: 'absolute',
    backgroundColor: 'rgba(255,255,255,0.11)',
    borderRadius: 3,
  },
  routeLine: {
    position: 'absolute',
    borderLeftWidth: 2,
    borderTopWidth: 2,
    borderColor: C.accentMint,
    borderStyle: 'dashed',
    opacity: 0.7,
  },
  destMarker: {
    position: 'absolute',
  },
  driverDot: {
    position: 'absolute',
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: C.ink,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: C.white,
  },
  userPulse: {
    position: 'absolute',
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: 'rgba(85,196,154,0.35)',
  },
  userDot: {
    position: 'absolute',
    width: 18,
    height: 18,
    borderRadius: 9,
    backgroundColor: C.accentMint,
    borderWidth: 3,
    borderColor: C.white,
  },
  searchRing: {
    position: 'absolute',
    width: 56,
    height: 56,
    borderRadius: 28,
    borderWidth: 1.5,
    borderColor: C.accentMint,
  },
  geofenceBadge: {
    position: 'absolute',
    bottom: 10,
    right: 12,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    backgroundColor: 'rgba(0,0,0,0.45)',
    borderRadius: 99,
    paddingHorizontal: 10,
    paddingVertical: 4,
  },
  geofenceText: {
    fontSize: 10,
    color: C.accentMint,
    fontWeight: '600',
    letterSpacing: 0.4,
  },

  zoneBanner: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 8,
    marginHorizontal: 16,
    marginTop: 10,
    backgroundColor: 'rgba(217,92,53,0.10)',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: 'rgba(217,92,53,0.2)',
    padding: 10,
  },
  zoneBannerText: { flex: 1, fontSize: 11.5, color: C.badge, lineHeight: 16 },

  sheet: {
    flex: 1,
    paddingHorizontal: 20,
    paddingTop: 12,
  },
  sheetHandle: {
    alignSelf: 'center',
    width: 36,
    height: 4,
    borderRadius: 2,
    backgroundColor: C.border,
    marginBottom: 14,
  },
  sheetTitle: { fontSize: 20, fontWeight: '700', color: C.ink, letterSpacing: -0.5 },
  sheetSub: { fontSize: 12, color: C.inkSoft, marginTop: 2 },

  placeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    height: 50,
    borderRadius: 18,
    paddingHorizontal: 14,
    gap: 10,
  },
  placeDot: {
    width: 10, height: 10, borderRadius: 5,
    backgroundColor: C.border, borderWidth: 1.5, borderColor: C.silver,
  },
  placeDotActive: {
    backgroundColor: C.accentMint, borderColor: C.accentMint,
  },
  placeText: { flex: 1, fontSize: 13.5, color: C.ink, fontWeight: '500' },
  placeTextPlaceholder: { color: C.inkSoft, fontWeight: '400' },

  dropdown: {
    marginTop: 4,
    borderRadius: 18,
    backgroundColor: C.white,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: C.border,
  },
  dropSearch: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: C.border,
  },
  dropInput: { flex: 1, fontSize: 13, color: C.ink },
  dropItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingHorizontal: 14,
    paddingVertical: 11,
    borderBottomWidth: 1,
    borderBottomColor: C.mist,
  },
  dropItemText: { fontSize: 13, color: C.ink },
  dropEmpty: { fontSize: 13, color: C.inkSoft, textAlign: 'center', paddingVertical: 16 },

  priceCard: {
    borderRadius: 20,
    padding: 14,
    marginTop: 12,
  },
  priceRow: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  priceIcon: {
    width: 44, height: 44, borderRadius: 14,
    backgroundColor: C.mist, alignItems: 'center', justifyContent: 'center',
  },
  priceLabel: { fontSize: 14, fontWeight: '600', color: C.ink },
  priceSub: { fontSize: 11, color: C.inkSoft, marginTop: 1 },
  priceAmount: { fontSize: 18, fontWeight: '700', color: C.ink },
  priceMeta: { flexDirection: 'row', alignItems: 'center', gap: 5, marginTop: 10 },
  priceMetaText: { fontSize: 11, color: C.inkSoft },
  priceSep: { width: 3, height: 3, borderRadius: 1.5, backgroundColor: C.silver },

  primaryBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    height: 52,
    borderRadius: 20,
    backgroundColor: C.ink,
    marginTop: 14,
    ...S.float,
  },
  primaryBtnDisabled: { opacity: 0.4 },
  primaryBtnText: { fontSize: 15, fontWeight: '600', color: C.white },

  findingHeader: {
    flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between',
    marginBottom: 14,
  },
  etaBubble: {
    backgroundColor: C.mist,
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 6,
  },
  etaText: { fontSize: 15, fontWeight: '700', color: C.ink },
  liveBadge: {
    borderRadius: 99,
    paddingHorizontal: 12,
    paddingVertical: 5,
  },
  liveBadgeText: { fontSize: 10, fontWeight: '700', color: C.white, letterSpacing: 1 },

  driverCard: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 20,
    padding: 14,
    gap: 12,
  },
  driverAvatar: {
    width: 48, height: 48, borderRadius: 24,
    backgroundColor: C.ink, alignItems: 'center', justifyContent: 'center',
  },
  driverAvatarText: { color: C.white, fontSize: 15, fontWeight: '700' },
  driverName: { fontSize: 14, fontWeight: '600', color: C.ink },
  driverCarText: { fontSize: 11.5, color: C.inkSoft, marginTop: 1 },
  ratingRow: { flexDirection: 'row', alignItems: 'center', gap: 3, marginTop: 3 },
  ratingBadge: { flexDirection: 'row', alignItems: 'center', gap: 3 },
  ratingText: { fontSize: 11.5, color: C.inkSoft, fontWeight: '500' },
  plateBadge: {
    backgroundColor: C.mist,
    borderRadius: 8,
    paddingHorizontal: 10,
    paddingVertical: 6,
    alignItems: 'center',
  },
  plateText: { fontSize: 11, fontWeight: '600', color: C.ink, letterSpacing: 0.5 },

  tripSummaryRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 12,
    backgroundColor: C.snow,
    borderRadius: 14,
    padding: 12,
    gap: 4,
  },
  tripDot: {
    width: 8, height: 8, borderRadius: 4,
    backgroundColor: C.ink, flexShrink: 0,
  },
  tripStopText: { flex: 1, fontSize: 12, color: C.inkSoft, fontWeight: '500' },

  cancelBtn: {
    alignItems: 'center',
    justifyContent: 'center',
    height: 48,
    borderRadius: 18,
    borderWidth: 1.5,
    borderColor: C.border,
    marginTop: 10,
  },
  cancelBtnText: { fontSize: 14, fontWeight: '600', color: C.inkSoft },

  routeCard: {
    borderRadius: 20,
    padding: 14,
    marginTop: 10,
    gap: 2,
  },
  routeRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  routeText: { fontSize: 13, fontWeight: '500', color: C.ink },
  routeConnector: {
    width: 2, height: 16, backgroundColor: C.border,
    marginLeft: 3, marginVertical: 2,
  },
  routePayRow: {
    flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 10,
    paddingTop: 10, borderTopWidth: 1, borderTopColor: C.border,
  },
  routePayText: { fontSize: 11.5, color: C.inkSoft },

  tripPriceBadge: { alignItems: 'flex-end' },
  tripPriceLabel: { fontSize: 10, color: C.inkSoft },
  tripPriceAmount: { fontSize: 20, fontWeight: '700', color: C.ink },

  arrivedScreen: {
    flex: 1,
    alignItems: 'center',
    paddingHorizontal: 24,
  },
  successCircle: {
    width: 90, height: 90, borderRadius: 45,
    alignItems: 'center', justifyContent: 'center',
    marginBottom: 20,
    ...S.float,
  },
  arrivedTitle: { fontSize: 26, fontWeight: '700', color: C.ink, letterSpacing: -0.5 },
  arrivedSub: { fontSize: 13, color: C.inkSoft, marginTop: 4, textAlign: 'center' },
  arrivedCard: {
    width: '100%', borderRadius: 22, padding: 16, marginTop: 24, gap: 0,
  },
  arrivedRow: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  arrivedDivider: { height: 1, backgroundColor: C.border, marginVertical: 12 },
  arrivedDriverName: { fontSize: 14, fontWeight: '600', color: C.ink },
  arrivedDriverCar: { fontSize: 11.5, color: C.inkSoft, marginTop: 1 },
  driverAvatarSm: {
    width: 40, height: 40, borderRadius: 20,
    backgroundColor: C.ink, alignItems: 'center', justifyContent: 'center',
  },
  driverAvatarSmText: { color: C.white, fontSize: 13, fontWeight: '700' },
  arrivedPayRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  arrivedPayText: { flex: 1, fontSize: 13, color: C.inkSoft },
  paidBadge: {
    backgroundColor: 'rgba(85,196,154,0.15)',
    borderRadius: 99, paddingHorizontal: 10, paddingVertical: 4,
  },
  paidBadgeText: { fontSize: 11, fontWeight: '600', color: C.accentMint },
});
