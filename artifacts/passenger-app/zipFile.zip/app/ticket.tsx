import { useEffect, useMemo, useRef } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Platform, ScrollView, Animated, Easing } from 'react-native';
import { router } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import Svg, { Rect, Path } from 'react-native-svg';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import * as Haptics from 'expo-haptics';
import { useBooking } from '@/context/BookingContext';
import { useTheme } from '@/context/ThemeContext';
import { ThemeColors, S } from '@/constants/colors';

const SEAT = 'B4';
const BOOKING_ID = '#VG-29471';

function SparkleParticle({ deg, delay, color }: { deg: number; delay: number; color: string }) {
  const opacity = useRef(new Animated.Value(0)).current;
  const distance = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.sequence([
      Animated.delay(delay * 1000),
      Animated.parallel([
        Animated.sequence([
          Animated.timing(opacity, { toValue: 1, duration: 350, useNativeDriver: true }),
          Animated.timing(opacity, { toValue: 0, duration: 700, useNativeDriver: true }),
        ]),
        Animated.timing(distance, { toValue: 1, duration: 900, easing: Easing.out(Easing.ease), useNativeDriver: true }),
      ]),
    ]).start();
  }, []);

  const radians = ((deg - 90) * Math.PI) / 180;
  const radius = 54;

  const translateX = distance.interpolate({ inputRange: [0, 1], outputRange: [0, Math.cos(radians) * radius] });
  const translateY = distance.interpolate({ inputRange: [0, 1], outputRange: [0, Math.sin(radians) * radius] });

  return (
    <Animated.View
      style={[
        { position: 'absolute', width: 7, height: 7, borderRadius: 3.5, backgroundColor: color },
        { opacity, transform: [{ translateX }, { translateY }] },
      ]}
    />
  );
}

const SPARKLE_DEGREES = [0, 60, 120, 180, 240, 300];
const SPARKLE_DELAYS = [0.1, 0.15, 0.2, 0.1, 0.18, 0.12];

function QRMock({ bg, fg }: { bg: string; fg: string }) {
  return (
    <View style={{ backgroundColor: bg, borderRadius: 16, padding: 10, alignItems: 'center', justifyContent: 'center' }}>
      <Svg viewBox="0 0 100 100" width={80} height={80}>
        <Rect x="5" y="5" width="30" height="30" rx="4" fill={bg} />
        <Rect x="12" y="12" width="16" height="16" rx="2" fill={fg} />
        <Rect x="65" y="5" width="30" height="30" rx="4" fill={bg} />
        <Rect x="72" y="12" width="16" height="16" rx="2" fill={fg} />
        <Rect x="5" y="65" width="30" height="30" rx="4" fill={bg} />
        <Rect x="12" y="72" width="16" height="16" rx="2" fill={fg} />
        {[[40, 10], [50, 10], [60, 10], [40, 20], [60, 20], [40, 30], [50, 30], [60, 30],
          [40, 45], [50, 45], [60, 45], [40, 55], [55, 55], [45, 65], [60, 65], [50, 75], [60, 75],
          [40, 85], [50, 85], [60, 85], [70, 50], [80, 50], [75, 60], [80, 70], [70, 80]
        ].map(([x, y], i) => <Rect key={i} x={x} y={y} width="8" height="8" rx="1" fill={bg} />)}
      </Svg>
    </View>
  );
}

function makeStyles(c: ThemeColors) {
  return StyleSheet.create({
    header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 20, paddingBottom: 12 },
    headerBtn: { width: 40, height: 40, alignItems: 'center', justifyContent: 'center', backgroundColor: c.isDark ? 'rgba(255,255,255,0.08)' : 'rgba(255,255,255,0.7)', borderRadius: 20, borderWidth: 1, borderColor: c.isDark ? 'rgba(255,255,255,0.12)' : 'rgba(255,255,255,0.6)' },
    headerTitle: { fontSize: 15, fontWeight: '600', color: c.ink, letterSpacing: -0.2 },
    scrollContent: { paddingHorizontal: 20, gap: 20, paddingTop: 4 },
    confirmBlock: { alignItems: 'center', gap: 10 },
    sparkleHost: { width: 80, height: 80, alignItems: 'center', justifyContent: 'center', position: 'relative' },
    checkCircle: { width: 72, height: 72, borderRadius: 36, backgroundColor: c.ink, alignItems: 'center', justifyContent: 'center', shadowColor: c.ink, shadowOffset: { width: 0, height: 14 }, shadowOpacity: 0.25, shadowRadius: 28, elevation: 10 },
    confirmedLabel: { fontSize: 22, fontWeight: '700', color: c.ink, letterSpacing: -0.5, fontFamily: 'Inter_700Bold' },
    bookingId: { fontSize: 12, color: c.inkSoft, fontFamily: 'Inter_400Regular' },
    ticketCard: { borderRadius: 32, overflow: 'hidden', backgroundColor: c.white, ...S.float },
    ticketHeader: { padding: 20, borderTopLeftRadius: 32, borderTopRightRadius: 32, overflow: 'hidden' },
    ticketHeaderGlow: { position: 'absolute', top: -40, right: -40, width: 160, height: 160, borderRadius: 80, backgroundColor: 'rgba(255,255,255,0.06)' },
    ticketHeaderContent: { flexDirection: 'row', alignItems: 'flex-start', gap: 12 },
    ticketCodeLabel: { fontSize: 9, color: 'rgba(255,255,255,0.55)', textTransform: 'uppercase', letterSpacing: 1 },
    ticketCode: { fontSize: 20, fontWeight: '700', color: '#ffffff' },
    ticketHeaderMid: { flex: 1 },
    ticketRouteName: { fontSize: 13, fontWeight: '600', color: '#ffffff', marginBottom: 6 },
    ticketRouteRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
    ticketStation: { flexDirection: 'row', alignItems: 'center', gap: 5, flex: 1, minWidth: 0 },
    ticketStationText: { fontSize: 11, color: 'rgba(255,255,255,0.8)', flex: 1 },
    ticketTimeBox: { alignItems: 'flex-end' },
    ticketTimeLabel: { fontSize: 9, color: 'rgba(255,255,255,0.55)', textTransform: 'uppercase', letterSpacing: 1 },
    ticketTime: { fontSize: 18, fontWeight: '700', color: '#ffffff' },
    perforationRow: { flexDirection: 'row', alignItems: 'center', height: 24, position: 'relative' },
    punchLeft: { width: 24, height: 24, borderRadius: 12, backgroundColor: c.isDark ? c.background : c.snow, marginLeft: -12 },
    perforationLine: { flex: 1, height: 1, borderTopWidth: 1.5, borderColor: c.border, borderStyle: 'dashed' },
    punchRight: { width: 24, height: 24, borderRadius: 12, backgroundColor: c.isDark ? c.background : c.snow, marginRight: -12 },
    ticketBody: { padding: 20, gap: 20, backgroundColor: c.white },
    ticketGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 0 },
    ticketGridItem: { width: '50%', paddingVertical: 8, paddingRight: 8 },
    ticketItemLabel: { fontSize: 10, color: c.inkSoft, textTransform: 'uppercase', letterSpacing: 0.9 },
    ticketItemValue: { fontSize: 14.5, fontWeight: '600', color: c.ink, marginTop: 2 },
    qrSection: { flexDirection: 'row', alignItems: 'center', gap: 16, paddingTop: 12, borderTopWidth: 1, borderTopColor: c.border },
    qrRight: { flex: 1, gap: 4 },
    qrText: { fontSize: 13.5, fontWeight: '600', color: c.ink },
    qrSub: { fontSize: 11, color: c.inkSoft },
    qrLiveBadge: { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 6 },
    qrLiveDot: { width: 7, height: 7, borderRadius: 3.5, backgroundColor: c.accentMint },
    qrLiveText: { fontSize: 11, fontWeight: '600', color: c.accentMint },
    actions: { gap: 10 },
    primaryBtn: { height: 56, borderRadius: 20, backgroundColor: c.ink, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, ...S.float },
    primaryBtnText: { color: c.isDark ? c.background : c.white, fontSize: 15, fontWeight: '600' },
    secondaryBtn: { height: 48, alignItems: 'center', justifyContent: 'center' },
    secondaryBtnText: { fontSize: 14, color: c.inkSoft },
    goHomeBtn: { marginTop: 20, height: 48, paddingHorizontal: 24, borderRadius: 16, backgroundColor: c.ink, alignItems: 'center', justifyContent: 'center' },
    goHomeBtnText: { color: c.isDark ? c.background : c.white, fontSize: 14, fontWeight: '600' },
  });
}

export default function TicketScreen() {
  const insets = useSafeAreaInsets();
  const top = Platform.OS === 'web' ? 60 : insets.top;
  const { activeBooking } = useBooking();
  const { colors: c, t } = useTheme();
  const styles = useMemo(() => makeStyles(c), [c]);

  const checkScale = useRef(new Animated.Value(0.6)).current;
  const checkOpacity = useRef(new Animated.Value(0)).current;
  const checkRotate = useRef(new Animated.Value(-20)).current;
  const cardY = useRef(new Animated.Value(30)).current;
  const cardOpacity = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    Animated.parallel([
      Animated.spring(checkScale, { toValue: 1, damping: 12, stiffness: 140, useNativeDriver: true }),
      Animated.timing(checkOpacity, { toValue: 1, duration: 350, useNativeDriver: true }),
      Animated.spring(checkRotate, { toValue: 0, damping: 16, useNativeDriver: true }),
      Animated.sequence([
        Animated.delay(200),
        Animated.spring(cardY, { toValue: 0, damping: 22, stiffness: 130, useNativeDriver: true }),
      ]),
      Animated.sequence([
        Animated.delay(200),
        Animated.timing(cardOpacity, { toValue: 1, duration: 350, useNativeDriver: true }),
      ]),
    ]).start();
  }, []);

  const rotateDeg = checkRotate.interpolate({ inputRange: [-20, 0], outputRange: ['-20deg', '0deg'] });

  const booking = activeBooking;
  if (!booking) return (
    <LinearGradient colors={c.luxeGrad} style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <Text style={{ fontSize: 16, color: c.inkSoft }}>{t('no_booking')}</Text>
      <TouchableOpacity onPress={() => router.replace('/(tabs)')} style={styles.goHomeBtn}>
        <Text style={styles.goHomeBtnText}>{t('go_home')}</Text>
      </TouchableOpacity>
    </LinearGradient>
  );

  return (
    <LinearGradient colors={c.luxeGrad} style={{ flex: 1 }}>
      <View style={[styles.header, { paddingTop: top + 12 }]}>
        <TouchableOpacity style={styles.headerBtn} onPress={() => router.replace('/(tabs)')} activeOpacity={0.8}>
          <Ionicons name="close" size={18} color={c.ink} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>{t('boarding_pass')}</Text>
        <TouchableOpacity style={styles.headerBtn} activeOpacity={0.8} onPress={() => Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light)}>
          <Ionicons name="share-outline" size={16} color={c.ink} />
        </TouchableOpacity>
      </View>

      <ScrollView style={{ flex: 1 }} contentContainerStyle={[styles.scrollContent, { paddingBottom: 48 }]} showsVerticalScrollIndicator={false}>
        <View style={styles.confirmBlock}>
          <View style={styles.sparkleHost}>
            {SPARKLE_DEGREES.map((deg, i) => <SparkleParticle key={deg} deg={deg} delay={SPARKLE_DELAYS[i]} color={c.ink} />)}
            <Animated.View
              style={[
                styles.checkCircle,
                { opacity: checkOpacity, transform: [{ scale: checkScale }, { rotate: rotateDeg }] },
              ]}
            >
              <Ionicons name="checkmark" size={28} color={c.isDark ? c.background : '#ffffff'} />
            </Animated.View>
          </View>
          <Text style={styles.confirmedLabel}>{t('booking_confirmed')}</Text>
          <Text style={styles.bookingId}>{BOOKING_ID}</Text>
        </View>

        <Animated.View style={[styles.ticketCard, { opacity: cardOpacity, transform: [{ translateY: cardY }] }]}>
          <LinearGradient colors={[c.ink, c.isDark ? '#2a2a4a' : '#2a2a3e']} style={styles.ticketHeader} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}>
            <View style={styles.ticketHeaderGlow} />
            <View style={styles.ticketHeaderContent}>
              <View>
                <Text style={styles.ticketCodeLabel}>{t('line')}</Text>
                <Text style={styles.ticketCode}>{booking.route.code}</Text>
              </View>
              <View style={styles.ticketHeaderMid}>
                <Text style={styles.ticketRouteName}>{booking.route.name}</Text>
                <View style={styles.ticketRouteRow}>
                  <View style={styles.ticketStation}>
                    <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: '#ffffff', flexShrink: 0 }} />
                    <Text style={styles.ticketStationText} numberOfLines={1}>{booking.route.path[booking.fromIdx].name}</Text>
                  </View>
                  <Ionicons name="arrow-forward" size={10} color="rgba(255,255,255,0.5)" />
                  <View style={styles.ticketStation}>
                    <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: c.accentMint, flexShrink: 0 }} />
                    <Text style={styles.ticketStationText} numberOfLines={1}>{booking.route.path[booking.toIdx].name}</Text>
                  </View>
                </View>
              </View>
              <View style={styles.ticketTimeBox}>
                <Text style={styles.ticketTimeLabel}>{t('dep')}</Text>
                <Text style={styles.ticketTime}>{booking.time}</Text>
              </View>
            </View>
          </LinearGradient>

          <View style={styles.perforationRow}>
            <View style={styles.punchLeft} />
            <View style={styles.perforationLine} />
            <View style={styles.punchRight} />
          </View>

          <View style={styles.ticketBody}>
            <View style={styles.ticketGrid}>
              {[
                { label: t('date'), value: booking.date },
                { label: t('passengers'), value: booking.passengers.toString() },
                { label: t('seat'), value: SEAT },
                { label: t('total'), value: `${booking.price} ${t('egp')}` },
              ].map((item) => (
                <View key={item.label} style={styles.ticketGridItem}>
                  <Text style={styles.ticketItemLabel}>{item.label}</Text>
                  <Text style={styles.ticketItemValue}>{item.value}</Text>
                </View>
              ))}
            </View>

            <View style={styles.qrSection}>
              <QRMock bg={c.isDark ? c.mist : c.snow} fg={c.isDark ? c.ink : '#1e1e28'} />
              <View style={styles.qrRight}>
                <Text style={styles.qrText}>{t('scan_boarding')}</Text>
                <Text style={styles.qrSub}>{t('show_driver')}</Text>
                <View style={styles.qrLiveBadge}>
                  <View style={styles.qrLiveDot} />
                  <Text style={styles.qrLiveText}>{t('active')}</Text>
                </View>
              </View>
            </View>
          </View>
        </Animated.View>

        <View style={styles.actions}>
          <TouchableOpacity style={styles.primaryBtn} activeOpacity={0.9} onPress={() => router.replace('/(tabs)/trips')}>
            <Text style={styles.primaryBtnText}>{t('view_all_trips')}</Text>
            <Ionicons name="ticket-outline" size={16} color={c.isDark ? c.background : '#ffffff'} />
          </TouchableOpacity>
          <TouchableOpacity style={styles.secondaryBtn} activeOpacity={0.8} onPress={() => router.replace('/(tabs)')}>
            <Text style={styles.secondaryBtnText}>{t('back_home')}</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </LinearGradient>
  );
}
