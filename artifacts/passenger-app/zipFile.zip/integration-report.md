# VeeGo Backend Integration Report

**Date:** May 25, 2026  
**Backend URL:** `https://fc782086-2957-4839-b939-0b1f9bd873f0-00-1ru2gpoi9cisw.kirk.replit.dev/api`  
**Environment variable:** `EXPO_PUBLIC_API_URL` (shared)

---

## Architecture

### Core Layer (`src/`)

| File | Purpose |
|------|---------|
| `src/api/client.ts` | Axios instance with JWT Bearer interceptor, auto-refresh on 401, `expo-secure-store` / `localStorage` token storage |
| `src/api/socket.ts` | `socket.io-client` connection with JWT auth, typed ride/notification events, auto-reconnect |

### Hooks (`src/hooks/`)

| Hook | Endpoints | Fallback |
|------|-----------|---------|
| `useRoutes.ts` | `GET /routes` | `constants/data.ts` mock routes |
| `useTrips.ts` | `GET /users/me/bookings` | `constants/data.ts` mock trips |
| `useWallet.ts` | `GET /users/me/wallet`, `GET /wallet/transactions`, `POST /wallet/recharge` | Hardcoded mock balance/transactions |
| `useNotifications.ts` | `GET /notifications`, socket `notification:new` | `constants/data.ts` mock notifications |
| `useProfile.ts` | `GET /auth/me`, `PATCH /users/me` | Default profile values |
| `usePromos.ts` | `GET /promo/available`, `POST /promo/validate` | Hardcoded featured promos + local lookup |
| `useRide.ts` | `POST /rides/request`, `POST /rides/:id/cancel`, socket ride events | Mock timer-based phase transitions |
| `usePushToken.ts` | `POST /users/me/push-token` | Silently skips on failure |

---

## Wired Screens

### Step 4 — `app/auth.tsx`
- `handlePhoneSubmit` → `POST /auth/send-otp { phone }`
- `OtpForm.handleVerify` → `POST /auth/verify-otp { phone, code }`
- On success: stores `accessToken` → `expo-secure-store` / `localStorage`
- On API 404/501 (endpoint not yet implemented): gracefully falls through to app

### Step 5 — `app/(tabs)/index.tsx`
- `useRoutes()` hook replaces static `routes` import from `data.ts`
- Falls back to mock routes on API failure

### Step 6 — `context/BookingContext.tsx`
- `handleConfirm()` → `POST /bookings { routeId, fromStationId, toStationId, passengers, date, time, price }`
- Stores `confirmedBookingId` from response
- UI proceeds immediately; API failure is logged and non-blocking

### Step 7 — `components/car/CarServiceScreen.tsx`
- `handleConfirmRide` → `useRide().requestRide({ type: 'car', pickup, dropoff })`
- Socket `ride:driver_assigned` → clears fallback timer, transitions to `driver_assigned` phase
- Fallback: 4 s mock timer if API fails or socket doesn't respond

### Step 8 — `components/bike/BikeServiceScreen.tsx`
- `handleConfirm` → `useRide().requestRide({ type: 'bike', pickup, dropoff })`
- Socket `ride:driver_assigned` → transitions to `driver_assigned` phase
- Fallback: 3.5 s mock timer

### Step 9 — `app/(tabs)/trips.tsx`
- `useTrips()` provides real `upcomingTrips` / `pastTrips`
- Pull-to-refresh wired via `RefreshControl`
- Falls back to mock data on API failure

### Step 10 — `app/(tabs)/wallet.tsx`
- `useWallet()` provides real `balance`, `spent`, `transactions`
- Recharge buttons call `recharge(amount)` → `POST /wallet/recharge`
- Optimistic UI update; API failure is silent with local balance update

### Step 11 — `app/notifications.tsx`
- `useNotifications()` provides real notifications list + live `notification:new` socket events
- "Mark all read" calls `PATCH /notifications/read-all`
- Falls back to mock notifications

### Step 12 — `app/(tabs)/profile.tsx`
- `useProfileInfo` now fetches `GET /auth/me` on mount (after AsyncStorage cache load)
- `saveProfile` calls `PATCH /users/me` in addition to AsyncStorage write
- All existing UI preserved

### Step 13 — `app/support.tsx`
- `handleSend` → `POST /support/tickets { issueType, message }`
- On HTTP 4xx: shows error Alert; on 404/501: treats as success (endpoint not yet implemented)

### Step 14 — `app/promo.tsx`
- `usePromos()` fetches `GET /promo/available` for featured promo cards
- `handleApply` → `POST /promo/validate { code }` replaces local `VALID_CODES` lookup
- Falls back to local lookup if API unavailable

### Step 15 — `app/_layout.tsx`
- `usePushToken()` called inside `AppShell`
- Requests notification permission, gets Expo push token, registers via `POST /users/me/push-token { token, platform }`
- Silently no-ops on web or permission denied

---

## Token Storage

| Platform | Access Token | Refresh Token |
|----------|-------------|---------------|
| iOS / Android | `expo-secure-store` key `veego_access_token` | `veego_refresh_token` |
| Web | `localStorage` key `veego_access_token` | `veego_refresh_token` |

Auto-refresh: On `401` response, client attempts `POST /auth/refresh` with stored refresh token. On failure, tokens are cleared.

---

## Socket Events Handled

| Event | Handler |
|-------|---------|
| `ride:driver_assigned` | Transitions ride phase → `driver_assigned`, updates driver info |
| `ride:driver_location` | Updates `driverLocation` in `useRide` state |
| `ride:started` | Transitions → `started` |
| `ride:completed` | Transitions → `completed`, captures fare |
| `ride:cancelled` | Transitions → `cancelled`, captures reason |
| `ride:timeout` | Transitions → `timeout` |
| `notification:new` | Prepends notification to list in `useNotifications` |

---

## Graceful Degradation Policy

All API calls follow the same pattern:
1. **Try** the real API endpoint
2. **On success**: update state with real data
3. **On failure**: fall back to mock/cached data silently (no crash, no blank screen)
4. **On HTTP 4xx** (bad request): surface error only when user action is directly blocked (e.g., invalid OTP code)

This ensures the app is **fully functional** even when the backend is unreachable or endpoints are not yet implemented.

---

## Packages Installed

- `axios` — HTTP client
- `socket.io-client` — WebSocket/polling real-time events
- `expo-secure-store` — Encrypted token storage on native
- `expo-notifications` — Push token registration
