import React, { createContext, useCallback, useContext, useState } from 'react';
import { router } from 'expo-router';
import type { Booking, Route } from '@/constants/data';
import api from '@/src/api/client';

type BookingContextType = {
  selectedRoute: Route | null;
  tripSheetOpen: boolean;
  confirmSheetOpen: boolean;
  pendingBooking: Booking | null;
  activeBooking: Booking | null;
  confirmedBookingId: string | null;
  openRoute: (route: Route) => void;
  closeTripSheet: () => void;
  handleBook: (booking: Booking) => void;
  handleConfirm: () => void;
  closeConfirmSheet: () => void;
  setActiveBooking: (b: Booking | null) => void;
};

const BookingContext = createContext<BookingContextType>({
  selectedRoute: null,
  tripSheetOpen: false,
  confirmSheetOpen: false,
  pendingBooking: null,
  activeBooking: null,
  confirmedBookingId: null,
  openRoute: () => {},
  closeTripSheet: () => {},
  handleBook: () => {},
  handleConfirm: () => {},
  closeConfirmSheet: () => {},
  setActiveBooking: () => {},
});

export function BookingProvider({ children }: { children: React.ReactNode }) {
  const [selectedRoute, setSelectedRoute] = useState<Route | null>(null);
  const [tripSheetOpen, setTripSheetOpen] = useState(false);
  const [confirmSheetOpen, setConfirmSheetOpen] = useState(false);
  const [pendingBooking, setPendingBooking] = useState<Booking | null>(null);
  const [activeBooking, setActiveBooking] = useState<Booking | null>(null);
  const [confirmedBookingId, setConfirmedBookingId] = useState<string | null>(null);

  const openRoute = useCallback((route: Route) => {
    setSelectedRoute(route);
    setTripSheetOpen(true);
  }, []);

  const closeTripSheet = useCallback(() => {
    setTripSheetOpen(false);
  }, []);

  const handleBook = useCallback((booking: Booking) => {
    setTripSheetOpen(false);
    setPendingBooking(booking);
    setTimeout(() => setConfirmSheetOpen(true), 280);
  }, []);

  const handleConfirm = useCallback(async () => {
    setConfirmSheetOpen(false);
    if (!pendingBooking) return;

    setActiveBooking(pendingBooking);

    try {
      const payload = {
        routeId: pendingBooking.route.id,
        fromStationId: pendingBooking.route.path[pendingBooking.fromIdx]?.id,
        toStationId: pendingBooking.route.path[pendingBooking.toIdx]?.id,
        passengers: pendingBooking.passengers,
        date: pendingBooking.date,
        time: pendingBooking.time,
        price: pendingBooking.price,
      };
      const { data } = await api.post('/bookings', payload);
      const bookingId = data.bookingId ?? data.id ?? data._id ?? null;
      if (bookingId) setConfirmedBookingId(String(bookingId));
    } catch (e: any) {
      console.warn('[BookingContext] POST /bookings failed:', e?.response?.data?.message ?? e?.message);
    }

    setTimeout(() => router.push('/ticket'), 260);
  }, [pendingBooking]);

  const closeConfirmSheet = useCallback(() => {
    setConfirmSheetOpen(false);
  }, []);

  return (
    <BookingContext.Provider
      value={{
        selectedRoute,
        tripSheetOpen,
        confirmSheetOpen,
        pendingBooking,
        activeBooking,
        confirmedBookingId,
        openRoute,
        closeTripSheet,
        handleBook,
        handleConfirm,
        closeConfirmSheet,
        setActiveBooking,
      }}
    >
      {children}
    </BookingContext.Provider>
  );
}

export function useBooking() {
  return useContext(BookingContext);
}
