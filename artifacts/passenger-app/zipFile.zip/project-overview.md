# VeeGo — Passenger App: Project Overview

> **Last updated:** May 25, 2026  
> **Status:** Frontend-only. No backend exists yet. All data is mocked locally.

---

## 1. What This Project Is

**VeeGo** is a React Native (Expo) ride-hailing and shuttle booking app targeting **Wadi El Gedid (New Valley), Egypt**. It supports three service types:

| Service | Description |
|---------|-------------|
| **Shuttle** | Fixed-route bus lines between stations (like a mini metro) |
| **Car** | On-demand private ride-hailing (Economy / Premium) |
| **Bike** | Motorcycle-based on-demand rides |

**Delivery** is shown in the UI but marked "Coming Soon."

Currency: **EGP (Egyptian Pounds)**  
Languages: **English + Arabic (RTL supported)**  
Target platform: **iOS + Android** (web preview included)

---

## 2. Current Architecture

```
app/                        Expo Router screens (file-based routing)
  (tabs)/                   Tab bar screens: Home, Routes, Trips, Wallet, Profile
  auth.tsx                  Sign in / Sign up / Forgot / OTP (simulated)
  onboarding.tsx            3-step onboarding carousel
  notifications.tsx         Notification list
  stations.tsx              Nearby stations map view
  ticket.tsx                Booking confirmation + QR code

components/
  car/                      Car ride flow (map, options sheet, driver card, chat)
  bike/                     Bike ride flow
  shared/                   Rating sheet

context/
  BookingContext.tsx         Global shuttle booking state machine
  FavoritesContext.tsx       Saved route IDs in AsyncStorage
  ThemeContext.tsx           Dark mode + language preferences

constants/
  data.ts                   ALL mock data (stations, routes, trips, notifications)
  i18n.ts                   English + Arabic translations
  colors.ts                 Design tokens

hooks/
  useRecentSearches.ts      Recent car/bike search destinations (AsyncStorage)
```

### Tech Stack

| Layer | Package | Version |
|-------|---------|---------|
| Framework | Expo SDK | ~54 |
| Router | expo-router | ~6 |
| Animations | react-native-reanimated | ~4.1 |
| Gestures | react-native-gesture-handler | ~2.28 |
| Maps | react-native-maps | ^1.27 |
| Data fetching | @tanstack/react-query | ^5.59 |
| Storage | @react-native-async-storage/async-storage | 2.2.0 |
| HTTP client | **Not installed** (needs axios or fetch wrapper) |
| Realtime | **Not installed** (needs socket.io-client) |

---

## 3. Backend — Does Not Exist Yet

**There is currently no backend.** No HTTP requests are made anywhere in the codebase. No base URL, no API client, no socket connection. Everything is:

- Hardcoded in `constants/data.ts`
- Stored locally in `AsyncStorage`
- Simulated with `setTimeout` (e.g., 3.5-second driver search → driver assigned)

The backend needs to be built from scratch before the mobile app can go to production.

### Recommended Backend Stack

```
Node.js + Express (or Fastify)
PostgreSQL — relational data (users, routes, bookings, drivers)
Redis — session cache, socket rooms, rate limiting
Socket.IO — realtime driver tracking and ride status
JWT — access + refresh token auth
Twilio / Vonage — OTP SMS delivery
```

---

## 4. Required Backend Base URL

Once built, configure in the app as an environment variable:

```
EXPO_PUBLIC_API_URL=https://api.veego.app/v1
EXPO_PUBLIC_SOCKET_URL=https://ws.veego.app
```

For local development:
```
EXPO_PUBLIC_API_URL=http://localhost:3000/v1
EXPO_PUBLIC_SOCKET_URL=http://localhost:3000
```

---

## 5. Authentication Flow

### Current (Simulated)

1. User enters phone number (+ name for sign-up)
2. "Send Code" button sets local state to OTP step — **no SMS is sent**
3. User enters any 4–6 digit code — **any value is accepted**
4. Session saved to AsyncStorage: `@veego_session_v1 → { phone, name, loggedInAt }`
5. User redirected to `/(tabs)`

### Required Backend Auth Flow

```
POST /auth/send-otp
  Body:    { phone: "+201XXXXXXXXX" }
  Returns: { message: "OTP sent" }

POST /auth/verify-otp
  Body:    { phone: "+201XXXXXXXXX", code: "123456" }
  Returns: { accessToken, refreshToken, user: { id, phone, name, isNewUser } }

POST /auth/register          (called automatically if isNewUser = true)
  Headers: Authorization: Bearer <accessToken>
  Body:    { name: "Full Name" }
  Returns: { user: { id, phone, name, createdAt } }

POST /auth/refresh
  Body:    { refreshToken }
  Returns: { accessToken, refreshToken }

POST /auth/logout
  Headers: Authorization: Bearer <accessToken>
  Returns: { success: true }
```

### AsyncStorage Keys (already in use)

| Key | Contents |
|-----|----------|
| `@veego_session_v1` | `{ phone, name, loggedInAt }` |
| `@veego_prefs_v1` | `{ darkMode: bool, language: "en" \| "ar" }` |
| `@veego_favorites_v1` | `string[]` (route IDs) |
| `@veego_recent_car_v1` | `string[]` (last 5 car destinations) |
| `@veego_recent_bike_v1` | `string[]` (last 5 bike destinations) |

When the real backend is integrated, `@veego_session_v1` should be replaced with a proper token store.

---

## 6. Database Models (Derived from Frontend Mock Data)

These are the data shapes the frontend expects. The backend DB should match.

### User
```typescript
{
  id: string              // UUID
  phone: string           // "+201XXXXXXXXX" — primary identifier
  name: string
  email?: string
  dateOfBirth?: string
  avatarUrl?: string
  isVerified: boolean
  walletBalance: number   // EGP cents or float
  totalTrips: number
  averageRating: number   // as a passenger
  createdAt: string
}
```

### Station
```typescript
{
  id: string              // "s1", "s2" ... or UUID
  name: string            // "الخارجة — وسط المدينة"
  area: string            // "الخارجة"
  latitude: number        // 25.4529
  longitude: number       // 30.5523
  distanceFromUser?: string  // computed by API
  etaFromUser?: string       // computed by API
}
```

### Route (Shuttle Line)
```typescript
{
  id: string
  code: string            // "L01", "L02"
  name: string            // "خط الخارجة السريع"
  from: string            // station name
  to: string              // station name
  color: string           // hex color for UI
  stations: number        // stop count
  path: Station[]         // ordered stops
  totalSeats: number
  seatsLeft: number       // real-time
  price: number           // base fare EGP
  duration: string        // "28 دقيقة"
  nextDeparture: string   // "08:45"
}
```

### Booking (Shuttle)
```typescript
{
  id: string
  userId: string
  routeId: string
  fromStationIdx: number
  toStationIdx: number
  passengers: number      // 1–3
  date: string            // ISO date
  time: string            // "08:45"
  price: number           // calculated fare
  seat: string            // assigned seat "B3"
  qrCode: string          // for ticket scan
  status: "upcoming" | "active" | "completed" | "cancelled"
  createdAt: string
}
```

### Trip (History item — covers shuttle/car/bike)
```typescript
{
  id: string
  userId: string
  type: "shuttle" | "car" | "bike"
  routeCode: string
  routeName: string
  from: string
  to: string
  date: string
  time: string
  seat: string            // "B3" for shuttle, "—" for car/bike
  status: "upcoming" | "completed" | "cancelled"
  price: number
  driverId?: string       // for car/bike only
  rating?: number         // passenger rating after trip
}
```

### Driver (Car / Bike)
```typescript
{
  id: string
  name: string            // "Ahmed Hassan"
  initials: string        // "AH"
  phone: string           // "+201234567890"
  vehicle: string         // "Toyota Camry 2022"
  plate: string           // "WG 1234"
  rating: number          // 4.8
  totalTrips: number
  color: string           // avatar background color
  latitude: number        // realtime (via socket)
  longitude: number
  isAvailable: boolean
}
```

### Car Ride Request
```typescript
{
  id: string
  passengerId: string
  driverId?: string
  pickupLocation: string  // name
  pickupLat: number
  pickupLng: number
  dropoffLocation: string
  dropoffLat: number
  dropoffLng: number
  rideType: "economy" | "premium"
  estimatedFare: number
  finalFare?: number
  status: "searching" | "driver_assigned" | "in_progress" | "completed" | "cancelled"
  createdAt: string
}
```

### Wallet
```typescript
{
  userId: string
  balance: number         // EGP
  transactions: [
    {
      id: string
      type: "recharge" | "ride_payment" | "refund" | "transfer"
      amount: number
      description: string
      createdAt: string
    }
  ]
}
```

### Notification
```typescript
{
  id: string
  userId: string
  category: "trip" | "promo" | "system"
  title: string
  body: string
  isRead: boolean
  createdAt: string
}
```

### Promo Code
```typescript
{
  id: string
  code: string
  discountType: "percent" | "fixed"
  discountValue: number
  minFare?: number
  expiresAt: string
  usageLimit: number
  usedCount: number
}
```

---

## 7. All API Endpoints Needed by the Passenger App

### Auth
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/auth/send-otp` | Send OTP to phone number |
| POST | `/auth/verify-otp` | Verify code, get tokens |
| POST | `/auth/refresh` | Refresh access token |
| POST | `/auth/logout` | Invalidate refresh token |

### User / Profile
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/users/me` | Get current user profile |
| PATCH | `/users/me` | Update name, email, DOB |
| DELETE | `/users/me` | Delete account |
| GET | `/users/me/stats` | Trip count, rating, savings |

### Shuttle Routes
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/routes` | List all shuttle routes |
| GET | `/routes/:id` | Get route detail (full path + seats) |
| GET | `/routes/search?from=&to=` | Search routes by origin/dest |

### Stations
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/stations` | List all stations |
| GET | `/stations/nearby?lat=&lng=` | Nearby stations sorted by distance |

### Bookings (Shuttle)
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/bookings` | Create a shuttle booking |
| GET | `/bookings/me` | List my bookings |
| GET | `/bookings/:id` | Get booking detail + QR |
| DELETE | `/bookings/:id` | Cancel a booking |

### Trips (History)
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/trips/me?status=upcoming\|completed` | My trip history |
| GET | `/trips/:id` | Trip detail |
| POST | `/trips/:id/rate` | Rate trip (1–5 stars + comment) |

### Car Rides
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/rides` | Create ride request (searching) |
| GET | `/rides/:id` | Ride status + driver info |
| DELETE | `/rides/:id` | Cancel ride |
| POST | `/rides/:id/complete` | Mark arrived (driver side) |
| POST | `/rides/:id/rate` | Rate driver after trip |

### Fare Estimation
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/rides/estimate` | Estimate fare before booking |

### Wallet
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/wallet/me` | Balance + recent transactions |
| POST | `/wallet/recharge` | Top-up wallet |
| POST | `/wallet/transfer` | Transfer to another user |

### Notifications
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/notifications/me` | List my notifications |
| PATCH | `/notifications/:id/read` | Mark as read |
| PATCH | `/notifications/me/read-all` | Mark all as read |
| GET | `/notifications/me/settings` | Get notification preferences |
| PATCH | `/notifications/me/settings` | Update preferences |

### Promo Codes
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/promos/apply` | Apply promo code to booking |

### Support
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/support/tickets` | Submit support request |
| GET | `/support/tickets/me` | List my support tickets |

### Favorites
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/favorites/me` | List saved routes |
| POST | `/favorites` | Add route to favorites |
| DELETE | `/favorites/:routeId` | Remove from favorites |

> **Note:** Favorites are currently stored 100% in AsyncStorage. This works for MVP but won't sync across devices. The backend endpoint is needed for proper multi-device support.

---

## 8. Socket.IO Events (Required for Car/Bike Realtime)

### Connection
```javascript
// Client connects with auth token
const socket = io(SOCKET_URL, {
  auth: { token: accessToken }
});
```

### Events the Passenger App Must **Emit**
| Event | Payload | When |
|-------|---------|------|
| `ride:request` | `{ rideId, pickupLat, pickupLng, dropoffLat, dropoffLng, rideType }` | User confirms ride |
| `ride:cancel` | `{ rideId }` | User cancels before assignment |
| `ride:complete_ack` | `{ rideId }` | Passenger confirms arrived |
| `location:update` | `{ lat, lng }` | Periodic passenger location |

### Events the Passenger App Must **Listen To**
| Event | Payload | Effect |
|-------|---------|--------|
| `ride:searching` | `{ rideId }` | Show "Searching for driver" UI |
| `ride:driver_assigned` | `{ rideId, driver: DriverObject }` | Show DriverAssignedCard |
| `ride:driver_location` | `{ rideId, lat, lng }` | Update driver pin on map |
| `ride:driver_arriving` | `{ rideId, etaSeconds }` | Show ETA countdown |
| `ride:started` | `{ rideId }` | Ride in progress state |
| `ride:completed` | `{ rideId, fare, duration }` | Show rating sheet |
| `ride:cancelled` | `{ rideId, reason }` | Return to idle state |
| `notification:new` | `{ notification: NotificationObject }` | Add to notification list |
| `shuttle:seat_update` | `{ routeId, seatsLeft }` | Update seat count on route card |

---

## 9. What Currently Works (Frontend Only)

| Feature | Status | Notes |
|---------|--------|-------|
| Onboarding (3 screens) | ✅ Works | Local only |
| Language selection (EN/AR) | ✅ Works | Persisted in AsyncStorage |
| Dark mode | ✅ Works | Persisted in AsyncStorage |
| Sign in / Sign up / Forgot password UI | ✅ Works | No real OTP sent |
| OTP verification | ✅ Works | Accepts ANY 4–6 digit code |
| Session persistence | ✅ Works | AsyncStorage only |
| Shuttle route listing | ✅ Works | Mock data only |
| Route detail + seat picker | ✅ Works | Mock data only |
| Booking confirmation + QR ticket | ✅ Works | Generated locally, not scannable |
| My Trips (upcoming / past) | ✅ Works | Mock data only |
| Car service — destination search | ✅ Works | 12 hardcoded Wadi El Gedid locations |
| Car service — ride type selection | ✅ Works | Economy (EGP 25) / Premium (EGP 45) |
| Car service — driver search animation | ✅ Works | 3.5-second timer, then mock driver |
| Car service — driver card (ETA countdown) | ✅ Works | Simulated 3-minute ETA |
| Car service — in-app chat UI | ✅ Works | No backend, messages are local only |
| Car service — trip rating | ✅ Works | Rating not saved anywhere |
| Notifications list | ✅ Works | 4 hardcoded mock notifications |
| Nearby stations map | ✅ Works | Mock coordinates (no real GPS yet) |
| Wallet screen | ✅ Works | Mock balance, no real transactions |
| Favorites (save/remove routes) | ✅ Works | AsyncStorage only |
| Recent car/bike searches | ✅ Works | AsyncStorage, max 5 |
| Profile settings screens | ✅ Works | Changes not saved to backend |
| Bike service | ✅ Works | Similar to car, all mocked |

---

## 10. What is Missing / Not Yet Implemented

### Critical (Blocks Production)

| # | Item | Impact |
|---|------|--------|
| 1 | **No backend API** | App is 100% offline; no real bookings |
| 2 | **No real OTP/SMS** | Any 4–6 digit code logs you in |
| 3 | **No JWT token auth** | No secure API calls possible |
| 4 | **No Socket.IO client** | Driver matching is a fake setTimeout |
| 5 | **No real-time driver location** | Map shows animated placeholder only |
| 6 | **No payment processing** | Wallet recharge button does nothing |
| 7 | **QR codes are not scannable** | Ticket QR is generated locally, driver app can't verify |
| 8 | **No push notifications** | expo-notifications not installed |
| 9 | **No real map integration** | CarMap is a custom SVG-grid simulation; no GPS routing |

### Important (Needed Before Launch)

| # | Item | Notes |
|---|------|--------|
| 10 | Seat assignment from backend | Backend must assign actual seat number |
| 11 | Real fare calculation | Backend must validate price (client-side only is unsafe) |
| 12 | Trip cancellation API | Currently UI-only, no backend state change |
| 13 | Rating persistence | Stars submitted but not saved |
| 14 | Support ticket submission | Form exists, sends nothing |
| 15 | Google Sign-In | Tapping "Continue with Google" auto-logs in with mock data |
| 16 | Promo code UI | Translations exist (`promos/apply`) but screen is not built |
| 17 | Multi-device favorites sync | Favorites only exist in local AsyncStorage |
| 18 | Expo push token registration | Needed for backend to send push notifications |

### Minor / Polish

| # | Item |
|---|------|
| 19 | `react-native-maps` version warning (1.27.2 vs expected 1.20.1) |
| 20 | `shadow*` deprecation warnings (use `boxShadow` for web) |
| 21 | Bike service screen is simpler than car — needs full feature parity |
| 22 | Delivery service is "Coming Soon" — needs design + backend |

---

## 11. Seed / Test Data

Since there is no backend, these are the mock values used throughout the app for testing the UI.

### Test Passenger Account
```
Phone:    +20 100 000 0000
Name:     Test User
OTP:      any 4–6 digits (e.g., 1234)
```

### Mock Driver (Car Service)
```
Name:     Ahmed Hassan
Phone:    +201234567890
Vehicle:  Toyota Camry 2022
Plate:    WG 1234
Rating:   4.8
ETA:      3 minutes
```

### Mock Shuttle Routes
| Code | Name | From → To | Price | Seats Left |
|------|------|-----------|-------|------------|
| L01 | خط الخارجة السريع | الخارجة وسط المدينة → جامعة وادي الجديد | EGP 15 | 7/18 |
| L02 | خط الداخلة | مستشفى الخارجة → قصر الداخلة | EGP 20 | 3/18 |
| L03 | خط الجامعة | الداخلة — موط → سوق الخارجة | EGP 12 | 12/18 |
| L04 | خط الليل | جامعة وادي الجديد → الخارجة وسط المدينة | EGP 10 | 16/18 |

### Mock Stations (Wadi El Gedid)
| ID | Name | Coordinates |
|----|------|-------------|
| s1 | الخارجة — وسط المدينة | 25.4529, 30.5523 |
| s2 | سوق الخارجة | ~25.452, 30.553 |
| s3 | مستشفى الخارجة | ~25.451, 30.553 |
| s4 | جامعة وادي الجديد | ~25.453, 30.554 |
| s5 | الداخلة — موط | ~25.452, 30.552 |
| s6 | قصر الداخلة | ~25.450, 30.549 |

### Car Ride Fares (Mock)
| Type | Price | ETA |
|------|-------|-----|
| Economy | EGP 25 | 4 min |
| Premium | EGP 45 | 6 min |

### Mock Car Destinations (12 locations in Wadi El Gedid)
- الخارجة — المركز
- الداخلة — الميدان الرئيسي
- موط — شارع الجمهورية
- الخارجة — السوق
- بلاط — مركز البلدة
- الجندل — الطريق الرئيسي
- الخارجة — المستشفى
- الداخلة — منطقة الفنادق
- الخارجة — المطار
- موط — محطة الباصات
- الداخلة — الجامعة
- الخارجة — الحي الجديد

---

## 12. Endpoint Review Results

**Verdict: No endpoints exist to test.**

Since there is no backend, the following review applies to the frontend data layer instead:

| Area | Status | Issue |
|------|--------|-------|
| Auth — OTP send | ❌ Not implemented | No SMS provider configured |
| Auth — OTP verify | ❌ Not implemented | Accepts any code, no validation |
| Auth — token storage | ⚠️ Partial | Phone+name stored; no JWT |
| Shuttle routes list | ✅ Mock works | Hardcoded in constants/data.ts |
| Seat availability | ⚠️ Static | `seatsLeft` never changes |
| Booking creation | ⚠️ Local only | Stored in BookingContext, lost on reload |
| Ticket QR | ⚠️ Not scannable | Generated as placeholder text |
| Trip history | ✅ Mock works | 5 hardcoded trips |
| Car ride matching | ⚠️ Simulated | 3.5s timeout → fake driver |
| Driver location | ❌ Not real | Animated SVG grid, no GPS |
| Wallet balance | ⚠️ Mock only | EGP 0, no transactions |
| Notifications | ✅ Mock works | 4 hardcoded items |
| Favorites | ✅ Works | AsyncStorage persistence |
| Support contact form | ❌ Not implemented | Form submits to nothing |
| Push notifications | ❌ Not installed | expo-notifications missing |

---

## 13. Integration Checklist for Backend Team

When the backend is ready, the frontend needs these changes:

```
1. Install: axios, socket.io-client, expo-notifications
2. Create: src/api/client.ts   (axios instance with base URL + token interceptor)
3. Create: src/api/socket.ts   (socket.io connection + event registry)
4. Replace: AsyncStorage session → secure token store (expo-secure-store)
5. Wire:    auth.tsx → POST /auth/send-otp + /auth/verify-otp
6. Wire:    routes tab → GET /routes
7. Wire:    booking flow → POST /bookings
8. Wire:    car flow → POST /rides + socket events
9. Wire:    trips tab → GET /trips/me
10. Wire:   wallet tab → GET /wallet/me
11. Wire:   notifications → GET /notifications/me + socket notification:new
12. Wire:   profile edits → PATCH /users/me
13. Wire:   favorites → GET+POST+DELETE /favorites (replace AsyncStorage)
14. Register Expo push token → POST /users/me/push-token
```

---

*This document was auto-generated by reviewing the VeeGo frontend codebase. It should be treated as a living document and updated as the backend is built out.*
